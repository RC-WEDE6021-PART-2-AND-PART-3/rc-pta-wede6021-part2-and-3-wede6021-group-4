<?php
echo "setup works!";
?>