// /pastimes2/js/script.js
// Dropdown menu functions
function toggleDD() {
    const dropdown = document.getElementById('mainDD');
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
}

function goPage(page) {
    window.location.href = '/pastimes2/' + page + '.php';
}

function goCategory(category) {
    window.location.href = '/pastimes2/shop.php?category=' + encodeURIComponent(category);
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('mainDD');
    if (dropdown && !e.target.closest('.dd-wrap')) {
        dropdown.classList.remove('open');
    }
});

// Also close dropdown on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const dropdown = document.getElementById('mainDD');
        if (dropdown) {
            dropdown.classList.remove('open');
        }
    }
});