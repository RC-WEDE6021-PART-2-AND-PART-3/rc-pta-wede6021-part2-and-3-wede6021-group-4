// js/dropdown.js
function toggleDD() {
    const dropdown = document.getElementById('mainDD');
    if (dropdown) {
        dropdown.classList.toggle('open');
    }
}

function goPage(page) {
    window.location.href = page + '.php';
}

function goCategory(category) {
    window.location.href = 'category.php?cat=' + encodeURIComponent(category);
}

document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('mainDD');
    if (dropdown && !e.target.closest('.dd-wrap')) {
        dropdown.classList.remove('open');
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const dropdown = document.getElementById('mainDD');
        if (dropdown) {
            dropdown.classList.remove('open');
        }
    }
});