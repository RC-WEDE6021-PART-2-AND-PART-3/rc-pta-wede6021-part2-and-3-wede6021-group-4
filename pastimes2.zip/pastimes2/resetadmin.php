<?php
$conn = new mysqli('127.0.0.1', 'root', '', 'ClothingStore', 3306);
$newPassword = password_hash('Admin@1234', PASSWORD_BCRYPT);
$stmt = $conn->prepare("UPDATE tblUser SET userPassword = ? WHERE username = 'adminuser'");
$stmt->bind_param("s", $newPassword);
if ($stmt->execute()) {
    echo "<p style='color:green'>Admin password reset successfully!</p>";
    echo "<p>Username: <strong>adminuser</strong></p>";
    echo "<p>Password: <strong>Admin@1234</strong></p>";
    echo "<p><a href='admin/login.php'>Go to Admin Login</a></p>";
} else {
    echo "<p style='color:red'>Failed: " . $stmt->error . "</p>";
}
$stmt->close();
$conn->close();
?>
