<?php
/**
 * register.php
 * Pastimes - User Registration Page
 * Student: Emihle Zifo (ST10452317) & Mzukisi Tekeni (ST10345918)
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - session_start() must be called BEFORE any HTML output
 * - password_hash() creates a secure bcrypt hash from the plain password
 * - Prepared statements prevent SQL Injection
 * - Sticky form: if validation fails, the user's input is preserved
 * - HTML5 validation (required, minlength) adds client-side checking
 */

session_start();
require_once 'DBConn.php';

$errors    = [];
$success   = '';

// "Sticky" form variables — preserve user input on error
$fullName  = '';
$email     = '';
$username  = '';
$role      = 'buyer';

// ============================================================
// PROCESS FORM SUBMISSION (POST request)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve and sanitize input
    // htmlspecialchars() converts < > " & to HTML entities (prevents XSS)
    // trim() removes leading/trailing whitespace
    $fullName = htmlspecialchars(trim($_POST['fullName'] ?? ''));
    $email    = htmlspecialchars(trim($_POST['email']    ?? ''));
    $username = htmlspecialchars(trim($_POST['username'] ?? ''));
    $password = $_POST['password']  ?? '';  // Don't encode — compare as-is
    $confirm  = $_POST['confirm']   ?? '';
    $role     = $_POST['role']      ?? 'buyer';

    // ---- Server-side Validation ----
    if (empty($fullName)) $errors[] = "Full name is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors[] = "A valid email address is required.";
    if (empty($username)) $errors[] = "Username is required.";

    /**
     * TEACHING NOTE: Password rules
     * strlen() counts characters. We require at least 8 (as per brief).
     */
    if (strlen($password) < 8)
        $errors[] = "Password must be at least 8 characters.";
    if ($password !== $confirm)
        $errors[] = "Passwords do not match.";
    if (!in_array($role, ['buyer','seller']))
        $errors[] = "Invalid role selected.";

    // ---- Check for duplicate email / username ----
    if (empty($errors)) {
        $checkStmt = $conn->prepare(
            "SELECT userID FROM tblUser WHERE email = ? OR username = ?"
        );
        $checkStmt->bind_param("ss", $email, $username);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $errors[] = "That email or username is already registered. Please login.";
        }
        $checkStmt->close();
    }

    // ---- If no errors, insert user ----
    if (empty($errors)) {
        /**
         * TEACHING NOTE:
         * password_hash($password, PASSWORD_BCRYPT) transforms the plain text
         * password into a 60-character bcrypt hash. This is one-way — you
         * cannot reverse it. To check a login you use password_verify().
         *
         * Example:
         * "mypassword" → "$2y$10$e0NRoASc5CGgo1pkToX.v.iHkO8qeGdkgO3b..."
         */
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // New sellers start as 'pending' — admin must verify before they can list
        $sellerStatus = ($role === 'seller') ? 'pending' : 'verified';

        $insertStmt = $conn->prepare(
            "INSERT INTO tblUser (fullName, email, username, userPassword, userRole, sellerStatus)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $insertStmt->bind_param("ssssss",
            $fullName, $email, $username, $hashedPassword, $role, $sellerStatus
        );

        if ($insertStmt->execute()) {
            $success = "Registration successful! ";
            if ($role === 'seller') {
                $success .= "Your account is <strong>pending admin verification</strong> before you can list items.";
            } else {
                $success .= "<a href='login.php'>Click here to login</a>.";
            }
            // Clear sticky form values on success
            $fullName = $email = $username = '';
            $role = 'buyer';
        } else {
            $errors[] = "Registration failed: " . $insertStmt->error;
        }
        $insertStmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<main class="auth-container">
    <div class="auth-card">
        <h1>Create an Account</h1>
        <p class="auth-subtitle">Join Pastimes — buy &amp; sell second-hand branded clothing</p>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <p><?= $success ?></p>
            </div>
        <?php endif; ?>

        <!--
            TEACHING NOTE: Sticky form
            Each input's value attribute shows the PHP variable.
            If the form is submitted with errors, the user's input
            is preserved so they don't have to retype everything.
            e.g. value="<?= $fullName ?>"
        -->
        <form method="POST" action="register.php" novalidate>

            <div class="form-group">
                <label for="fullName">Full Name *</label>
                <input type="text" id="fullName" name="fullName"
                       value="<?= htmlspecialchars($fullName) ?>"
                       placeholder="e.g. John Doe" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email"
                       value="<?= htmlspecialchars($email) ?>"
                       placeholder="e.g. john@example.com" required>
            </div>

            <div class="form-group">
                <label for="username">Username *</label>
                <input type="text" id="username" name="username"
                       value="<?= htmlspecialchars($username) ?>"
                       placeholder="Choose a username" required>
            </div>

            <div class="form-group">
                <label for="password">Password * <small>(min. 8 characters)</small></label>
                <input type="password" id="password" name="password"
                       minlength="8" placeholder="Min. 8 characters" required>
            </div>

            <div class="form-group">
                <label for="confirm">Confirm Password *</label>
                <input type="password" id="confirm" name="confirm"
                       minlength="8" placeholder="Repeat your password" required>
            </div>

            <div class="form-group">
                <label for="role">I want to *</label>
                <select id="role" name="role">
                    <option value="buyer"  <?= ($role === 'buyer')  ? 'selected' : '' ?>>Buy clothing</option>
                    <option value="seller" <?= ($role === 'seller') ? 'selected' : '' ?>>Sell clothing</option>
                </select>
                <?php if ($role === 'seller'): ?>
                    <small class="hint">Sellers require admin verification before listing items.</small>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary btn-full">Create Account</button>
        </form>

        <p class="auth-switch">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
