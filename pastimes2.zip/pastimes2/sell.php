<?php
/**
 * sell.php
 * Pastimes — Sell Item Listing Page
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Only accessible to users with seller role.
 * - Checks seller verification status before allowing listing.
 * - Form collects item details: brand, category, size, condition, price, description.
 * - Supports image upload with live preview using JavaScript.
 * - Inserts new product into tblClothes table with 'available' status.
 * - Displays verification banner showing seller approval status.
 * - Unverified sellers cannot list items until admin approves them.
 */
session_start();
require_once 'DBConn.php';

// Check if user is logged in
if (!isset($_SESSION['userID'])) {
    header('Location: login.php');
    exit();
}

// Get user details including seller verification status
$userID = $_SESSION['userID'];
$userQuery = $conn->query("SELECT userRole, sellerStatus FROM tblUser WHERE userID = $userID");
$userData = $userQuery->fetch_assoc();

$userRole = $userData['userRole'];
$sellerStatus = $userData['sellerStatus'] ?? 'pending';

// Check if user is a seller
if ($userRole !== 'seller') {
    header('Location: index.php');
    exit();
}

// Check if seller is verified
$isVerified = ($sellerStatus === 'verified');
$isPending = ($sellerStatus === 'pending');
$isRejected = ($sellerStatus === 'rejected');

$message = '';
$error = '';

// Handle form submission (only if verified)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isVerified) {
    $brand = trim($_POST['brand'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $size = trim($_POST['size'] ?? '');
    $condition = trim($_POST['condition'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $colour = trim($_POST['colour'] ?? '');
    $shipping = trim($_POST['shipping'] ?? '');
    $sellerID = $_SESSION['userID'];
    
    // Validation
    if (empty($brand) || empty($category) || empty($size) || empty($condition) || $price <= 0) {
        $error = 'Please fill in all required fields';
    } else {
        // Handle image upload if any
        $imagePath = '';
        if (isset($_FILES['photo1']) && $_FILES['photo1']['error'] == 0) {
            $target_dir = "uploads/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $imagePath = $target_dir . time() . "_" . basename($_FILES['photo1']['name']);
            move_uploaded_file($_FILES['photo1']['tmp_name'], $imagePath);
        }
        
        // Insert into database
        $sql = "INSERT INTO tblClothes (sellerID, brand, category, clothesSize, conditionRating, price, description, imagePath, clothesStatus, listedAt) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', NOW())";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssdss", $sellerID, $brand, $category, $size, $condition, $price, $description, $imagePath);
        
        if ($stmt->execute()) {
            $message = 'Item listed successfully!';
            $_POST = array();
        } else {
            $error = 'Error: ' . $conn->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell an Item - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Sell Page Styles - Maroon/Reddish Theme */
        .sell-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .sell-wrap {
            max-width: 860px;
            margin: 0 auto;
            padding: 1.5rem 0 3rem;
        }

        .sell-h1 {
            font-family: 'Playfair Display', serif;
            font-size: 34px;
            font-weight: 700;
            margin-bottom: .5rem;
            color: #1C1C1A;
        }

        .sell-desc {
            color: #8C8478;
            font-size: 15px;
            margin-bottom: 2.5rem;
        }

        /* Card borders - Maroon color */
        .sell-card {
            background: #FFFDF9;
            border: 1px solid #8B1A1A;
            border-radius: 16px;
            padding: 1.75rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(139, 26, 26, 0.08);
        }

        .sell-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: .6rem;
            color: #1C1C1A;
        }

        /* Verification Banner */
        .verification-banner {
            background: #FFFDF9;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
            border-left: 4px solid;
        }

        .verification-banner.verified {
            border-left-color: #065F46;
            background: #D1FAE5;
        }
        .verification-banner.verified h3 { color: #065F46; }

        .verification-banner.pending {
            border-left-color: #92400E;
            background: #FEF3C7;
        }
        .verification-banner.pending h3 { color: #92400E; }

        .verification-banner.rejected {
            border-left-color: #991B1B;
            background: #FEE2E2;
        }
        .verification-banner.rejected h3 { color: #991B1B; }

        .verification-banner h3 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            margin-bottom: 0.5rem;
        }

        .verification-banner p {
            font-size: 13px;
            margin-bottom: 0;
        }

        .btn-disabled {
            background: #9CA3AF !important;
            cursor: not-allowed !important;
            transform: none !important;
        }

        /* Photo upload slots - Maroon border on hover */
        .photo-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: .75rem;
        }

        .photo-slot {
            aspect-ratio: 3/4;
            border: 2px dashed #D4C4A8;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            background: #FAF7F2;
            gap: 4px;
            transition: .15s;
            color: #8C8478;
            font-size: 11px;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }

        .photo-slot:hover {
            border-color: #8B1A1A;
            color: #8B1A1A;
        }

        .photo-slot .plus {
            font-size: 22px;
            line-height: 1;
            color: inherit;
        }

        .image-preview {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }

        /* Form inputs - Maroon focus border */
        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .07em;
            color: #8C8478;
            margin-bottom: 6px;
        }

        .form-input {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid #D4C4A8;
            border-radius: 10px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            background: #FFFFFF;
            color: #1C1C1A;
            transition: all 0.2s;
        }

        .form-input:focus {
            outline: none;
            border-color: #8B1A1A;
            box-shadow: 0 0 0 3px rgba(139, 26, 26, 0.1);
        }

        .form-grid2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        /* Info box - Maroon left border */
        .info-box {
            background: #FAF7F2;
            border-radius: 10px;
            padding: 1rem;
            margin-top: 1rem;
            font-size: 13px;
            color: #8C8478;
            line-height: 1.7;
            border-left: 3px solid #8B1A1A;
        }

        /* Buttons - Maroon theme */
        .sell-actions {
            display: flex;
            gap: 12px;
            margin-top: 1rem;
        }

        .btn-rust {
            background: #8B1A1A;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 12px 28px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-rust:hover {
            background: #6b1414;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(139, 26, 26, 0.3);
        }

        .btn-outline {
            background: transparent;
            color: #1C1C1A;
            border: 1.5px solid #D4C4A8;
            border-radius: 10px;
            padding: 11px 24px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-outline:hover {
            border-color: #8B1A1A;
            color: #8B1A1A;
        }

        /* Breadcrumb - Maroon hover */
        .breadcrumb {
            padding: 1rem 0;
            font-size: 13px;
            color: #8C8478;
        }

        .breadcrumb a {
            color: #8C8478;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            color: #8B1A1A;
        }

        .breadcrumb .sep {
            margin: 0 5px;
        }

        /* Message styles */
        .message-success {
            background: #D1FAE5;
            color: #065F46;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 3px solid #065F46;
        }
        
        .message-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 1rem;
            border-left: 3px solid #991B1B;
        }

        select.form-input {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%238C8478' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 14px center;
        }

        @media (max-width: 700px) {
            .photo-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            .form-grid2 {
                grid-template-columns: 1fr;
            }
            .sell-wrap {
                padding: 1rem 0;
            }
            .sell-container {
                padding: 0 1rem;
            }
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="sell-container">
    <div class="breadcrumb">
        <a href="index.php">Home</a> <span class="sep">/</span>
        <span>Sell an Item</span>
    </div>
    
    <div class="sell-wrap">
        <h1 class="sell-h1">List Your Item</h1>
        
        <!-- VERIFICATION STATUS BANNER -->
        <?php if ($isVerified): ?>
            <div class="verification-banner verified">
                <h3>✅ Verified Seller</h3>
                <p>Your seller account has been verified. You can now list items for sale on Pastimes.</p>
            </div>
        <?php elseif ($isPending): ?>
            <div class="verification-banner pending">
                <h3>⏳ Pending Verification</h3>
                <p>Your seller account is awaiting admin verification. You cannot list items until your account is verified. Please check back later.</p>
            </div>
        <?php elseif ($isRejected): ?>
            <div class="verification-banner rejected">
                <h3>❌ Verification Failed</h3>
                <p>Your seller application has been rejected. Please contact support for more information.</p>
            </div>
        <?php endif; ?>
        
        <p class="sell-desc">Fill in the details below to put your item in front of thousands of buyers across South Africa.</p>
        
        <?php if ($message): ?>
            <div class="message-success">✓ <?php echo $message; ?> <a href="category.php" style="color:#065F46; margin-left:10px;">View your listing →</a></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message-error">✗ <?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="sell-card">
                <h2><span>📸</span> Photos</h2>
                <div class="photo-grid">
                    <label class="photo-slot">
                        <input type="file" name="photo1" accept="image/*" style="display:none;" onchange="previewImage(this, 'preview1')">
                        <span class="plus">+</span>
                        <span>Main photo</span>
                        <img id="preview1" class="image-preview" style="display:none;">
                    </label>
                    <label class="photo-slot">
                        <input type="file" name="photo2" accept="image/*" style="display:none;" onchange="previewImage(this, 'preview2')">
                        <span class="plus">+</span>
                        <img id="preview2" class="image-preview" style="display:none;">
                    </label>
                    <label class="photo-slot">
                        <input type="file" name="photo3" accept="image/*" style="display:none;" onchange="previewImage(this, 'preview3')">
                        <span class="plus">+</span>
                        <img id="preview3" class="image-preview" style="display:none;">
                    </label>
                    <label class="photo-slot">
                        <input type="file" name="photo4" accept="image/*" style="display:none;" onchange="previewImage(this, 'preview4')">
                        <span class="plus">+</span>
                        <img id="preview4" class="image-preview" style="display:none;">
                    </label>
                    <label class="photo-slot">
                        <input type="file" name="photo5" accept="image/*" style="display:none;" onchange="previewImage(this, 'preview5')">
                        <span class="plus">+</span>
                        <img id="preview5" class="image-preview" style="display:none;">
                    </label>
                </div>
                <p style="font-size:12px; color:#8C8478; margin-top:.75rem">Up to 5 photos · JPG or PNG · Max 10MB each · First photo will be your main image</p>
            </div>

            <div class="sell-card">
                <h2><span>✏️</span> Item Details</h2>
                <div class="form-group">
                    <label class="form-label">Brand *</label>
                    <input class="form-input" name="brand" placeholder="e.g. Levi's, Nike, Zara" required value="<?php echo htmlspecialchars($_POST['brand'] ?? ''); ?>" <?php echo !$isVerified ? 'disabled' : ''; ?>>
                </div>
                <div class="form-grid2">
                    <div class="form-group">
                        <label class="form-label">Category *</label>
                        <select class="form-input" name="category" required <?php echo !$isVerified ? 'disabled' : ''; ?>>
                            <option value="">Select category</option>
                            <option value="Women" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Women') ? 'selected' : ''; ?>>Women</option>
                            <option value="Men" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Men') ? 'selected' : ''; ?>>Men</option>
                            <option value="Kids" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Kids') ? 'selected' : ''; ?>>Kids</option>
                            <option value="Shoes" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Shoes') ? 'selected' : ''; ?>>Shoes</option>
                            <option value="Accessories" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Accessories') ? 'selected' : ''; ?>>Accessories</option>
                            <option value="Vintage" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Vintage') ? 'selected' : ''; ?>>Vintage</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size *</label>
                        <select class="form-input" name="size" required <?php echo !$isVerified ? 'disabled' : ''; ?>>
                            <option value="">Select size</option>
                            <option value="XS" <?php echo (isset($_POST['size']) && $_POST['size'] == 'XS') ? 'selected' : ''; ?>>XS</option>
                            <option value="S" <?php echo (isset($_POST['size']) && $_POST['size'] == 'S') ? 'selected' : ''; ?>>S</option>
                            <option value="M" <?php echo (isset($_POST['size']) && $_POST['size'] == 'M') ? 'selected' : ''; ?>>M</option>
                            <option value="L" <?php echo (isset($_POST['size']) && $_POST['size'] == 'L') ? 'selected' : ''; ?>>L</option>
                            <option value="XL" <?php echo (isset($_POST['size']) && $_POST['size'] == 'XL') ? 'selected' : ''; ?>>XL</option>
                            <option value="XXL" <?php echo (isset($_POST['size']) && $_POST['size'] == 'XXL') ? 'selected' : ''; ?>>XXL</option>
                            <option value="One size" <?php echo (isset($_POST['size']) && $_POST['size'] == 'One size') ? 'selected' : ''; ?>>One size</option>
                        </select>
                    </div>
                </div>
                <div class="form-grid2">
                    <div class="form-group">
                        <label class="form-label">Condition *</label>
                        <select class="form-input" name="condition" required <?php echo !$isVerified ? 'disabled' : ''; ?>>
                            <option value="">Select condition</option>
                            <option value="Like new" <?php echo (isset($_POST['condition']) && $_POST['condition'] == 'Like new') ? 'selected' : ''; ?>>Like new — never worn</option>
                            <option value="Excellent" <?php echo (isset($_POST['condition']) && $_POST['condition'] == 'Excellent') ? 'selected' : ''; ?>>Excellent — worn once or twice</option>
                            <option value="Good" <?php echo (isset($_POST['condition']) && $_POST['condition'] == 'Good') ? 'selected' : ''; ?>>Good — light signs of wear</option>
                            <option value="Fair" <?php echo (isset($_POST['condition']) && $_POST['condition'] == 'Fair') ? 'selected' : ''; ?>>Fair — visible wear</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Colour</label>
                        <input class="form-input" name="colour" placeholder="e.g. Navy blue, Off-white" value="<?php echo htmlspecialchars($_POST['colour'] ?? ''); ?>" <?php echo !$isVerified ? 'disabled' : ''; ?>>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-input" name="description" rows="4" placeholder="Describe the item, any flaws, measurements, fabric composition, why you're selling…" style="resize:vertical" <?php echo !$isVerified ? 'disabled' : ''; ?>><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                </div>
            </div>

            <div class="sell-card">
                <h2><span>💸</span> Pricing &amp; Shipping</h2>
                <div class="form-grid2">
                    <div class="form-group">
                        <label class="form-label">Asking price (R) *</label>
                        <input class="form-input" type="number" step="0.01" name="price" placeholder="0.00" required value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>" <?php echo !$isVerified ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Shipping method</label>
                        <select class="form-input" name="shipping" <?php echo !$isVerified ? 'disabled' : ''; ?>>
                            <option value="Courier Guy — R79" <?php echo (isset($_POST['shipping']) && $_POST['shipping'] == 'Courier Guy — R79') ? 'selected' : ''; ?>>Courier Guy — R79</option>
                            <option value="Pargo Pickup Point — R49" <?php echo (isset($_POST['shipping']) && $_POST['shipping'] == 'Pargo Pickup Point — R49') ? 'selected' : ''; ?>>Pargo Pickup Point — R49</option>
                            <option value="PostNet to PostNet — R59" <?php echo (isset($_POST['shipping']) && $_POST['shipping'] == 'PostNet to PostNet — R59') ? 'selected' : ''; ?>>PostNet to PostNet — R59</option>
                            <option value="Buyer collects — Free" <?php echo (isset($_POST['shipping']) && $_POST['shipping'] == 'Buyer collects — Free') ? 'selected' : ''; ?>>Buyer collects — Free</option>
                        </select>
                    </div>
                </div>
                <div class="info-box">
                    💡 <strong>Pastimes earns 8% commission</strong> on each sale. Payments are held in escrow and released to your wallet within 3 business days of buyer confirmation. No upfront fees.
                </div>
            </div>

            <div class="sell-actions">
                <?php if ($isVerified): ?>
                    <button type="submit" class="btn-rust">Publish Listing</button>
                <?php else: ?>
                    <button type="button" class="btn-rust btn-disabled" disabled style="background:#9CA3AF; cursor:not-allowed;">Publish Listing (Account Not Verified)</button>
                <?php endif; ?>
                <button type="button" class="btn-outline" onclick="alert('Save as Draft - Demo')" <?php echo !$isVerified ? 'disabled' : ''; ?>>Save as Draft</button>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<script>
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    const parent = input.parentElement;
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            const plusSpan = parent.querySelector('.plus');
            const textSpan = parent.querySelector('span:not(.plus):not(.image-preview)');
            if (plusSpan) plusSpan.style.display = 'none';
            if (textSpan) textSpan.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
</body>
</html>