<?php
/**
 * includes/header.php
 * Pastimes — Global Header Component
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Included at the top of every page for consistent navigation.
 * - Displays announcement bar, logo, main navigation with dropdown menu.
 * - Shows login/register buttons or user info based on session.
 * - Cart icon shows item count from session cart array.
 * - Admin panel button appears for admin users.
 * - Logged-in bar shows user name, role, and seller verification status.
 * - Includes dropdown.js for interactive shop menu.
 */
$userRole = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$fullName = isset($_SESSION['fullName']) ? $_SESSION['fullName'] : '';

// Get cart item count from session
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<div class="announce-bar">Free delivery on orders over R500 · Sell your items and earn instantly</div>
<header class="site-header">
    <div class="container header-inner">
        <a href="/pastimes2/index.php" class="logo">PASTIMES</a>
        <nav class="site-nav">
            <div class="dd-wrap">
                <a href="javascript:void(0)" class="nav-item" onclick="toggleDD()">SHOP ▾</a>
                <div class="dropdown" id="mainDD">
                    <div class="dd-section-title">Shop by person</div>
                    <div class="dd-grid">
                        <a href="category.php?cat=Women" class="dd-item">
                            <div class="dd-icon" style="background:#F0E8E0">👚</div>
                            Women
                        </a>
                        <a href="category.php?cat=Men" class="dd-item">
                            <div class="dd-icon" style="background:#E0E8E0">👔</div>
                            Men
                        </a>
                        <a href="category.php?cat=Kids" class="dd-item">
                            <div class="dd-icon" style="background:#E8E0F0">🧒</div>
                            Kids
                        </a>
                        <a href="category.php?cat=Vintage" class="dd-item">
                            <div class="dd-icon" style="background:#F0E8D0">🕶️</div>
                            Vintage
                        </a>
                    </div>
                    <div class="dd-section-title">Shop by type</div>
                    <div class="dd-grid">
                        <a href="category.php?cat=Jackets" class="dd-item">
                            <div class="dd-icon" style="background:#E0E8F0">🧥</div>
                            Jackets
                        </a>
                        <a href="category.php?cat=Dresses" class="dd-item">
                            <div class="dd-icon" style="background:#F0E0E8">👗</div>
                            Dresses
                        </a>
                        <a href="category.php?cat=Shoes" class="dd-item">
                            <div class="dd-icon" style="background:#E8F0E0">👟</div>
                            Shoes
                        </a>
                        <a href="category.php?cat=Accessories" class="dd-item">
                            <div class="dd-icon" style="background:#F0F0E0">👜</div>
                            Bags
                        </a>
                        <a href="category.php?cat=Sale" class="dd-item">
                            <div class="dd-icon" style="background:#F8E8E0">🔥</div>
                            Sale
                        </a>
                        <a href="category.php?cat=New%20In" class="dd-item">
                            <div class="dd-icon" style="background:#E8F0E8">✨</div>
                            New In
                        </a>
                        <a href="category.php?cat=Designers" class="dd-item">
                            <div class="dd-icon" style="background:#F0E8F8">⭐</div>
                            Designers
                        </a>
                        <a href="sell.php" class="dd-item">
                            <div class="dd-icon" style="background:#FFF0E8">💸</div>
                            Sell on Pastimes
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Keep existing links -->
            <a href="/pastimes2/sale.php">SALE</a>
            <a href="/pastimes2/sell.php">SELL</a>
            <a href="/pastimes2/about.php">ABOUT</a>
        </nav>
        <div class="nav-icons">
            <?php if (!isset($_SESSION['userID'])): ?>
                <a href="/pastimes2/login.php" class="btn btn-outline btn-sm">Login</a>
                <a href="/pastimes2/register.php" class="btn btn-accent btn-sm">Register</a>
                <!-- AMAZON-STYLE CART ICON -->
                <a href="/pastimes2/cart.php" class="cart-link">
                    <svg class="cart-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <span class="cart-text">Cart</span>
                    <span class="cart-count-inside"><?php echo $cart_count; ?></span>
                </a>
            <?php else: ?>
                <a href="/pastimes2/logout.php" class="btn btn-sm logout-btn">Logout</a>
                <!-- AMAZON-STYLE CART ICON -->
                <a href="/pastimes2/cart.php" class="cart-link">
                    <svg class="cart-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <span class="cart-text">Cart</span>
                    <span class="cart-count-inside"><?php echo $cart_count; ?></span>
                </a>
                <!-- ADMIN PANEL BUTTON - Shows for ALL logged-in users (for testing) -->
                <a href="/pastimes2/admin/dashboard.php" class="btn btn-admin btn-sm">🔧 Admin</a>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (isset($_SESSION['userID'])): ?>
    <?php
    // Check if $conn exists before using it
    $sellerStatus = '';
    $statusText = '';
    $statusClass = '';
    
    if (isset($conn) && $conn && !$conn->connect_error) {
        $statusQuery = $conn->query("SELECT sellerStatus FROM tblUser WHERE userID = " . $_SESSION['userID']);
        if ($statusQuery && $statusQuery->num_rows > 0) {
            $sellerStatus = $statusQuery->fetch_assoc()['sellerStatus'] ?? '';
        }
    }
    
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'seller') {
        if ($sellerStatus == 'verified') {
            $statusText = '✓ Verified Seller';
            $statusClass = 'status-verified';
        } elseif ($sellerStatus == 'pending') {
            $statusText = '⏳ Pending Verification';
            $statusClass = 'status-pending';
        } elseif ($sellerStatus == 'rejected') {
            $statusText = '✗ Verification Failed';
            $statusClass = 'status-rejected';
        }
    }
    ?>
    <div class="logged-in-bar">
        User <strong><?= htmlspecialchars($fullName) ?></strong> is logged in
        &nbsp;|&nbsp; Role: <?= ucfirst($userRole) ?>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'seller' && $statusText): ?>
            &nbsp;|&nbsp; <span class="<?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
        <?php endif; ?>
        &nbsp;|&nbsp; <a href="/pastimes2/logout.php" style="color:#ffcdd2;text-decoration:underline;font-weight:600;">Logout</a>
    </div>
    <?php endif; ?>
    
    <script src="js/dropdown.js"></script>
</header>

<!-- Add Dropdown CSS -->
<style>
/* Dropdown Menu Styles */

.dd-item {
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 400;
    text-align: left;
    transition: .15s;
    color: #1C1C1A;
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
}

.dd-item:hover {
    background: #EDE8DF;
    color: #B85C38;
}


/* Cart */

.cart-link {
    display: flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    color: #1C1C1A;
    background: transparent;
    padding: 6px 12px;
    border-radius: 8px;
    transition: all 0.3s ease;
    margin-left: 8px;
}

.cart-link:hover {
    background: rgba(139, 26, 26, 0.1);
    color: #8B1A1A;
}

.cart-svg {
    width: 28px;
    height: 28px;
    stroke: currentColor;
}

.cart-text {
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 0.5px;
}

.cart-count-inside {
    background: #8B1A1A;
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    min-width: 26px;
    height: 26px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0 6px;
    margin-left: 4px;
    font-family: 'Inter', sans-serif;
}

/* Make sure nav-icons align properly */
.nav-icons {
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Button styles */
.btn {
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.3s ease;
}

.btn-outline {
    background: transparent;
    border: 2px solid #8B1A1A;
    color: #8B1A1A;
}

.btn-outline:hover {
    background: #8B1A1A;
    color: #fff;
}

.btn-accent {
    background: #8B1A1A;
    border: 2px solid #8B1A1A;
    color: #fff;
}

.btn-accent:hover {
    background: #6b1414;
    border-color: #6b1414;
}

.logout-btn {
    background: #fff;
    color: #8B1A1A;
    border: 2px solid #8B1A1A;
}

.logout-btn:hover {
    background: #8B1A1A;
    color: #fff;
}

/* Admin Button Style - For testing (shows for everyone) */
.btn-admin {
    background: #5C6B3A;
    border: 2px solid #5C6B3A;
    color: #fff;
}

.btn-admin:hover {
    background: #4a5a2e;
    border-color: #4a5a2e;
}

.btn-sm {
    padding: 6px 14px;
    font-size: 12px;
}

.status-verified {
    color: #D1FAE5;
}

.status-pending {
    color: #FEF3C7;
}

.status-rejected {
    color: #FEE2E2;
}
</style>