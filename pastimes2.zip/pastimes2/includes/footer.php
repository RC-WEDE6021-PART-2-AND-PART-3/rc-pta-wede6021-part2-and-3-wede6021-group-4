<?php
/**
 * includes/footer.php
 * Pastimes — Global Footer Component
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Included at the bottom of every page for consistent footer.
 * - Displays company info, social media links, and navigation links.
 * - Shop links filter category page by category parameter.
 * - "Coming Soon" popup for features not yet implemented.
 * - Responsive design adapts to mobile and tablet screens.
 * - Maroon background matches website color scheme.
 */
?>

<!-- Global Footer -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand-col">
      <div class="footer-brand">Pastimes</div>
      <p class="footer-desc">South Africa's most loved second-hand clothing platform. Buy, sell, and discover pre-loved fashion that's good for your wallet and the planet.</p>
      <div class="footer-social">
        <a href="javascript:void(0)" onclick="showComingSoon()" class="social-b">𝕏</a>
        <a href="javascript:void(0)" onclick="showComingSoon()" class="social-b">in</a>
        <a href="javascript:void(0)" onclick="showComingSoon()" class="social-b">ig</a>
        <a href="javascript:void(0)" onclick="showComingSoon()" class="social-b">fb</a>
      </div>
    </div>
    <div class="fcol">
      <h4>Shop</h4>
      <a href="category.php?cat=Women">Women</a>
      <a href="category.php?cat=Men">Men</a>
      <a href="category.php?cat=Kids">Kids</a>
      <a href="category.php?cat=Vintage">Vintage</a>
      <a href="category.php?cat=Sale">Sale</a>
    </div>
    <div class="fcol">
      <h4>Sell</h4>
      <a href="sell.php">List an item</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Seller guide</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Pricing &amp; fees</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Shipping guide</a>
    </div>
    <div class="fcol">
      <h4>Help</h4>
      <a href="javascript:void(0)" onclick="showComingSoon()">How it works</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Buyer protection</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Returns policy</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">Contact us</a>
      <a href="javascript:void(0)" onclick="showComingSoon()">FAQ</a>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2026 Pastimes · All rights reserved ·
    WEDE6021POE · Emihle Zifo (ST10452317) &amp; Mzukisi Tekeni (ST10345918)</p>
  </div>
</footer>

<style>
.site-footer {
  background: #8B1A1A;
  color: #ffffff;
  padding: 3rem 2rem 2rem;
  margin-top: 3rem;
}

.footer-inner {
  max-width: 1300px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 3rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.15);
}

.footer-brand {
  font-family: 'Playfair Display', serif;
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 0.75rem;
  color: #ffffff;
}

.footer-brand span {
  color: #B85C38;
}

.footer-desc {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.7;
  margin-bottom: 1.25rem;
  max-width: 280px;
}

.footer-social {
  display: flex;
  gap: 0.75rem;
}

.social-b {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  text-decoration: none;
  font-size: 14px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.social-b:hover {
  border-color: #B85C38;
  background: #B85C38;
}

.fcol h4 {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 1rem;
}

.fcol a {
  display: block;
  font-size: 13px;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 0.5rem;
  text-decoration: none;
  transition: color 0.3s ease;
  cursor: pointer;
}

.fcol a:hover {
  color: #ffffff;
  text-decoration: underline;
}

.footer-bottom {
  max-width: 1300px;
  margin: 0 auto;
  padding-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.5);
  flex-wrap: wrap;
  gap: 1rem;
}

/* Responsive Footer */
@media (max-width: 900px) {
  .footer-inner {
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
  }
  
  .site-footer {
    padding: 2rem 1.5rem 1.5rem;
  }
}

@media (max-width: 600px) {
  .footer-inner {
    grid-template-columns: 1fr;
    text-align: center;
    gap: 1.5rem;
  }
  
  .footer-desc {
    max-width: 100%;
  }
  
  .footer-social {
    justify-content: center;
  }
  
  .footer-bottom {
    flex-direction: column;
    text-align: center;
  }
  
  .fcol h4 {
    margin-top: 0.5rem;
  }
}

/* Coming Soon Toast/Notification */
.coming-soon-toast {
  position: fixed;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: #1C1C1A;
  color: #fff;
  padding: 12px 24px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: 500;
  z-index: 9999;
  opacity: 0;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  border-left: 4px solid #8B1A1A;
  white-space: nowrap;
}

.coming-soon-toast.show {
  transform: translateX(-50%) translateY(0);
  opacity: 1;
}

@media (max-width: 600px) {
  .coming-soon-toast {
    white-space: normal;
    text-align: center;
    max-width: 90%;
    font-size: 12px;
  }
}
</style>

<script>
function showComingSoon() {
  // Create toast element if it doesn't exist
  let toast = document.querySelector('.coming-soon-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'coming-soon-toast';
    document.body.appendChild(toast);
  }
  
  toast.textContent = '🚧 Coming Soon! This feature is under development.';
  toast.classList.add('show');
  
  // Hide after 3 seconds
  setTimeout(function() {
    toast.classList.remove('show');
  }, 3000);
}
</script>