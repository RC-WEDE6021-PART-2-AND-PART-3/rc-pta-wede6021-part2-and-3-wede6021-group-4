<?php
/**
 * login.php
 * Pastimes - User Login Page
 * Student: Emihle Zifo (ST10452317) & Mzukisi Tekeni (ST10345918)
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - session_start() MUST be before any HTML/output
 * - We compare entered password to stored hash using password_verify()
 * - Sticky form: username is kept on failed login (never password)
 * - If already logged in, redirect away from login page
 * - "User John Doe is logged in" string displayed at top after login
 * - The brief requires password compared to hash in tblUser
 */

session_start();
require_once 'DBConn.php';

// If already logged in, redirect to homepage
if (isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit;
}

$error    = '';
$username = ''; // Sticky form variable

// ============================================================
// PROCESS LOGIN FORM
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = htmlspecialchars(trim($_POST['username'] ?? ''));
    $password = $_POST['password'] ?? '';

    // ---- Basic HTML5-level server validation ----
    if (empty($username) || empty($password)) {
        $error = "Please enter both your username/email and password.";
    } else {

        /**
         * TEACHING NOTE:
         * We search by username OR email so users can login with either.
         * The ? placeholder in the prepared statement is replaced by the value
         * in bind_param() — this prevents SQL Injection completely.
         */
        $stmt = $conn->prepare(
            "SELECT userID, fullName, email, userPassword, userRole, sellerStatus
             FROM tblUser
             WHERE username = ? OR email = ?
             LIMIT 1"
        );
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();

        /**
         * TEACHING NOTE: Associative result set
         * bind_result() links variables to columns, OR we can use get_result()
         * with fetch_assoc() for array-style access (cleaner, used here).
         * This is the "associative read approach regarding the column names in a table"
         * mentioned in the brief.
         */
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc(); // Array with column names as keys

        if ($user) {
            /**
             * TEACHING NOTE: password_verify()
             * password_verify($entered, $storedHash) returns TRUE if the
             * entered plain password matches the stored bcrypt hash.
             * e.g. password_verify("mypassword", "$2y$10$...") → true/false
             */
            if (password_verify($password, $user['userPassword'])) {

                // ---- Successful login — store user info in SESSION ----
                /**
                 * TEACHING NOTE: PHP Sessions
                 * $_SESSION stores data that persists across page loads for one user.
                 * session_start() at the top of each page is required to access it.
                 * This is "managing state information" — the brief specifically lists it.
                 */
                $_SESSION['userID']   = $user['userID'];
                $_SESSION['fullName'] = $user['fullName'];
                $_SESSION['username'] = $user['username'] ?? $username;
                $_SESSION['role']     = $user['userRole'];
                $_SESSION['status']   = $user['sellerStatus'];

                // Redirect based on role
                if ($user['userRole'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: index.php");
                }
                exit;

            } else {
                // Wrong password — sticky form keeps username visible
                $error = "Incorrect password. Please try again.";
            }
        } else {
            $error = "No account found with that username or email.";
        }

        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<main class="auth-container">
    <div class="auth-card">
        <h1>Welcome Back</h1>
        <p class="auth-subtitle">Login to your Pastimes account</p>

        <?php if ($error): ?>
            <!--
                TEACHING NOTE: Sticky form in action
                When login fails, the error shows at the top AND the username
                field below is pre-filled with what the user typed.
                The password is NOT pre-filled (security best practice).
            -->
            <div class="alert alert-error">
                <p><?= $error ?></p>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php" novalidate>

            <div class="form-group">
                <label for="username">Username or Email *</label>
                <!--
                    STICKY FORM: value="<?= $username ?>" preserves the typed username
                    when the form is re-displayed after a failed login attempt.
                -->
                <input type="text" id="username" name="username"
                       value="<?= htmlspecialchars($username) ?>"
                       placeholder="Your username or email" required autofocus>
            </div>

            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" id="password" name="password"
                       placeholder="Your password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-full">Login</button>
        </form>

        <!-- Admin login button (brief requires separate admin access) -->
        <div class="admin-login-link">
            <a href="admin/login.php" class="btn btn-secondary btn-full">Admin Login</a>
        </div>

        <p class="auth-switch">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
