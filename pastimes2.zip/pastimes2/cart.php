<?php
/**
 * cart.php
 * Pastimes — Shopping Cart
 * Student: Emihle Zifo (ST10452317) & Mzukisi Tekeni (ST10345918)
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - The cart is stored in the PHP SESSION as an array of clothesIDs.
 * - When ?add=ID is in the URL, the item is added to the session cart.
 * - When ?remove=ID is in the URL, the item is removed from the session cart.
 * - The table fetches each cart item from tblClothes using an associative array (fetch_assoc).
 * - A JavaScript popup shows the SellPrice when AddToCart is clicked,
 *   then returns the user to the table — satisfying the brief requirement.
 */

session_start();
require_once 'DBConn.php';

// ============================================================
// GUARD: only logged-in buyers can use the cart
// ============================================================
if (!isset($_SESSION['userID']) || $_SESSION['role'] !== 'buyer') {
    header("Location: login.php");
    exit;
}

$message = '';
$order_message = '';

// ============================================================
// PLACE ORDER (Checkout)
// ============================================================
if (isset($_POST['place_order'])) {
    $buyerID = $_SESSION['userID'];
    $deliveryAddr = trim($_POST['delivery_address'] ?? '');
    $paymentMethod = trim($_POST['payment_method'] ?? '');

    if (empty($deliveryAddr)) {
        $order_message = 'Please enter your delivery address.';
    } else {
        $cartItems = [];
        $cartTotal = 0;

        if (!empty($_SESSION['cart'])) {
            $placeholders = implode(',', array_fill(0, count($_SESSION['cart']), '?'));
            $types = str_repeat('i', count($_SESSION['cart']));

            $stmt = $conn->prepare(
                "SELECT clothesID, price FROM tblClothes
                 WHERE clothesID IN ($placeholders) AND clothesStatus = 'available'"
            );
            $stmt->bind_param($types, ...$_SESSION['cart']);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $cartItems[] = $row;
                $cartTotal += $row['price'];
            }
            $stmt->close();
        }

        if (empty($cartItems)) {
            $order_message = 'Your cart is empty.';
        } else {
            $deliveryFee = ($cartTotal >= 500) ? 0 : 75;
            $finalTotal = $cartTotal + $deliveryFee;

            $conn->begin_transaction();

            try {
                $orderCount = 0;

                foreach ($cartItems as $item) {
                    $stmt = $conn->prepare(
                        "INSERT INTO tblOrder (buyerID, clothesID, total_amount, orderStatus, deliveryAddr, payment_method, orderDate)
                         VALUES (?, ?, ?, 'pending', ?, ?, NOW())"
                    );
                    $stmt->bind_param("iidss", $buyerID, $item['clothesID'], $item['price'], $deliveryAddr, $paymentMethod);

                    if ($stmt->execute()) {
                        $orderCount++;
                    }
                    $stmt->close();

                    // Mark item as sold
                    $updateStmt = $conn->prepare("UPDATE tblClothes SET clothesStatus = 'sold' WHERE clothesID = ?");
                    $updateStmt->bind_param("i", $item['clothesID']);
                    $updateStmt->execute();
                    $updateStmt->close();
                }

                if ($orderCount > 0) {
                    $conn->commit();
                    $_SESSION['cart'] = [];
                    header("Location: cart.php?order_success=1");
                    exit;
                } else {
                    throw new Exception("No orders were created.");
                }

            } catch (Exception $e) {
                $conn->rollback();
                $order_message = 'Error placing order: ' . $e->getMessage();
            }
        }
    }
}

// Order success message
if (isset($_GET['order_success'])) {
    $order_message = 'Your order has been placed successfully! Thank you for shopping with Pastimes.';
}

// ============================================================
// ADD ITEM TO CART (?add=clothesID)
// ============================================================
/**
 * TEACHING NOTE:
 * The cart is simply an array stored in $_SESSION['cart'].
 * We use the clothesID as a value so we can look it up in the DB.
 * in_array() prevents adding the same item twice.
 */
if (isset($_GET['add'])) {
    $addID = (int)$_GET['add'];

    $check = $conn->prepare(
        "SELECT clothesID, brand, category, price FROM tblClothes
         WHERE clothesID = ? AND clothesStatus = 'available' LIMIT 1"
    );
    $check->bind_param("i", $addID);
    $check->execute();
    $found = $check->get_result()->fetch_assoc();
    $check->close();

    if ($found) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        if (!in_array($addID, $_SESSION['cart'])) {
            $_SESSION['cart'][] = $addID;
            $addedPrice = number_format($found['price'], 2);
            $addedName  = htmlspecialchars($found['brand'] . ' ' . $found['category']);
        } else {
            $message = "This item is already in your cart.";
        }
    } else {
        $message = "Item not found or no longer available.";
    }
}

// ============================================================
// REMOVE ITEM FROM CART (?remove=clothesID)
// ============================================================
if (isset($_GET['remove'])) {
    $removeID = (int)$_GET['remove'];
    if (isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array_values(
            array_filter($_SESSION['cart'], fn($id) => $id !== $removeID)
        );
    }
    header("Location: cart.php");
    exit;
}

// ============================================================
// CLEAR ENTIRE CART (?clear=1)
// ============================================================
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit;
}

// ============================================================
// FETCH ALL CART ITEMS FROM DB (associative array approach)
// ============================================================
/**
 * TEACHING NOTE:
 * We use fetch_assoc() to read tblClothes as an associative array.
 * This means we access columns by name: $item['brand'], $item['price'], etc.
 * We JOIN tblUser so we can display the seller's username alongside each item.
 */
$cartItems = [];
$cartTotal = 0;

if (!empty($_SESSION['cart'])) {
    $placeholders = implode(',', array_fill(0, count($_SESSION['cart']), '?'));
    $types        = str_repeat('i', count($_SESSION['cart']));

    $stmt = $conn->prepare(
        "SELECT c.clothesID, c.brand, c.category, c.clothesSize,
                c.conditionRating, c.price, c.description, c.imagePath,
                u.username AS sellerName
         FROM   tblClothes c
         INNER JOIN tblUser u ON c.sellerID = u.userID
         WHERE  c.clothesID IN ($placeholders)
           AND  c.clothesStatus = 'available'
         ORDER BY c.brand ASC"
    );

    $stmt->bind_param($types, ...$_SESSION['cart']);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $cartItems[] = $row;
        $cartTotal  += $row['price'];
    }
    $stmt->close();
}

$deliveryFee = ($cartTotal >= 500) ? 0 : 75;
$finalTotal  = $cartTotal + $deliveryFee;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart — Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .cart-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px 60px;
        }
        .cart-container h1 {
            font-size: 1.8rem;
            margin-bottom: 8px;
            color: var(--primary);
        }
        .cart-subtitle {
            color: var(--muted);
            margin-bottom: 28px;
            font-size: 0.95rem;
        }
        .cart-wrapper {
            display: grid;
            grid-template-columns: 1fr 360px;
            gap: 2rem;
        }
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--white);
            border-radius: var(--radius);
            overflow: hidden;
            border: 1px solid var(--border);
        }
        .cart-table thead {
            background: var(--primary);
            color: var(--white);
        }
        .cart-table thead th {
            padding: 14px 16px;
            text-align: left;
            font-size: 0.88rem;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        .cart-table tbody tr {
            border-bottom: 1px solid var(--border);
            transition: background 0.15s;
        }
        .cart-table tbody tr:last-child { border-bottom: none; }
        .cart-table tbody tr:hover { background: #fdf8f7; }
        .cart-table td {
            padding: 14px 16px;
            vertical-align: middle;
            font-size: 0.93rem;
        }
        .item-thumb {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: var(--radius);
            border: 1px solid var(--border);
        }
        .item-thumb-placeholder {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #f5eeed, #e8d5d0);
            border-radius: var(--radius);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            border: 1px solid var(--border);
        }
        .item-brand {
            font-weight: 700;
            color: var(--primary);
            font-size: 0.95rem;
        }
        .item-desc {
            color: var(--muted);
            font-size: 0.82rem;
            margin-top: 3px;
        }
        .item-price {
            font-weight: 700;
            color: var(--primary);
            font-size: 1rem;
            white-space: nowrap;
        }
        .btn-remove {
            background: transparent;
            color: var(--error);
            border: 1px solid var(--error);
            padding: 5px 12px;
            border-radius: var(--radius);
            font-size: 0.82rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.2s;
            display: inline-block;
        }
        .btn-remove:hover { background: var(--error); color: #fff; text-decoration: none; }
        .cart-summary {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 24px 28px;
            position: sticky;
            top: 100px;
        }
        .cart-summary h2 {
            font-size: 1.1rem;
            margin-bottom: 16px;
            color: var(--primary);
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            font-size: 0.93rem;
            margin-bottom: 10px;
            color: var(--muted);
        }
        .summary-total {
            border-top: 2px solid var(--primary);
            margin-top: 14px;
            padding-top: 14px;
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--primary);
        }
        .delivery-address { margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--border); }
        .delivery-address label { display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 8px; color: var(--primary); }
        .delivery-address textarea { width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 8px; font-size: 0.85rem; resize: vertical; font-family: inherit; }
        .payment-method { margin-top: 15px; }
        .payment-method label { display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 8px; color: var(--primary); }
        .payment-method select { width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 8px; font-size: 0.85rem; background: white; }
        .btn-place-order { width: 100%; background: var(--primary); color: white; border: none; padding: 14px; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 20px; transition: background 0.3s; }
        .btn-place-order:hover { background: #6b1414; }
        .cart-actions { display: flex; gap: 12px; margin-top: 18px; }
        .cart-empty { text-align: center; padding: 60px 20px; color: var(--muted); }
        .cart-empty p { font-size: 1rem; margin-bottom: 20px; }
        .message-success { background: #D1FAE5; color: #065F46; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; border-left: 3px solid #065F46; }
        .message-error { background: #FEE2E2; color: #991B1B; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; border-left: 3px solid #991B1B; }
        @media (max-width: 900px) {
            .cart-wrapper { grid-template-columns: 1fr; }
            .cart-summary { position: static; }
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<!--
    ============================================================
    SELL PRICE POPUP OVERLAY
    ============================================================
    TEACHING NOTE:
    This popup is shown using JavaScript when the page loads
    with ?showpopup=1 in the URL. It displays the item name
    and SellPrice. Clicking "Return to Table" hides the popup
    and shows the cart table — satisfying the rubric requirement.
-->
<div id="cartPopup" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:999; align-items:center; justify-content:center;">
    <div style="background:#fff; border-radius:12px; padding:36px 40px; max-width:380px; width:90%; text-align:center; box-shadow:0 8px 32px rgba(0,0,0,0.18);">
        <div style="font-size:2.8rem; margin-bottom:12px;">🛒</div>
        <div style="font-size:1.15rem; font-weight:700; color:#8B1A1A; margin-bottom:6px;">Added to Cart!</div>
        <div id="popupItemName" style="color:#8C8478; font-size:0.9rem; margin-bottom:18px;"></div>
        <div style="font-size:2rem; font-weight:900; color:#8B1A1A; margin-bottom:22px;">
            <small style="font-size:1rem; font-weight:400; color:#8C8478; display:block; margin-bottom:4px;">Sell Price</small>
            R<span id="popupPrice">0.00</span>
        </div>
        <button onclick="closePopup()" style="width:100%; background:#8B1A1A; color:#fff; border:none; padding:12px; border-radius:8px; font-size:15px; font-weight:600; cursor:pointer; font-family:inherit;">← Return to Table</button>
    </div>
</div>

<main class="cart-container">
    <h1>My Cart</h1>
    <p class="cart-subtitle">Items you've added — ready to checkout</p>

    <?php if ($message): ?>
        <div class="message-error"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($order_message): ?>
        <div class="message-success">✓ <?= htmlspecialchars($order_message) ?></div>
    <?php endif; ?>

    <?php if (!empty($cartItems)): ?>

    <div class="cart-wrapper">
        <!-- CART ITEMS TABLE -->
        <div>
            <!--
                TEACHING NOTE: fetch_assoc() in a while loop
                Each cart item is displayed by reading from the $cartItems array,
                which was populated using fetch_assoc() above.
                Columns are accessed by name: $item['brand'], $item['price'], etc.
            -->
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Picture</th>
                        <th>Item</th>
                        <th>Size</th>
                        <th>Condition</th>
                        <th>Seller</th>
                        <th>Sell Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <!-- PICTURE COLUMN -->
                        <td>
                            <?php if (!empty($item['imagePath']) && file_exists($item['imagePath'])): ?>
                                <img class="item-thumb"
                                     src="<?= htmlspecialchars($item['imagePath']) ?>"
                                     alt="<?= htmlspecialchars($item['brand']) ?>">
                            <?php else: ?>
                                <div class="item-thumb-placeholder">👗</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="item-brand"><?= htmlspecialchars($item['brand']) ?></div>
                            <div class="item-desc"><?= htmlspecialchars($item['category']) ?></div>
                        </td>
                        <td><?= htmlspecialchars($item['clothesSize']) ?></td>
                        <td><?= htmlspecialchars($item['conditionRating']) ?></td>
                        <td>@<?= htmlspecialchars($item['sellerName']) ?></td>
                        <td class="item-price">R<?= number_format($item['price'], 2) ?></td>
                        <td>
                            <a href="cart.php?remove=<?= $item['clothesID'] ?>"
                               class="btn-remove"
                               onclick="return confirm('Remove this item from your cart?')">Remove</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="cart-actions">
                <a href="category.php" class="btn btn-outline" style="flex:1; text-align:center;">Continue Shopping</a>
                <a href="cart.php?clear=1"
                   class="btn btn-danger"
                   style="flex:1; text-align:center;"
                   onclick="return confirm('Clear your entire cart?')">Clear Cart</a>
            </div>
        </div>

        <!-- ORDER SUMMARY & CHECKOUT -->
        <div class="cart-summary">
            <h2>Order Summary</h2>
            <div class="summary-row">
                <span>Subtotal (<?= count($cartItems) ?> items)</span>
                <span>R<?= number_format($cartTotal, 2) ?></span>
            </div>
            <div class="summary-row">
                <span>Delivery</span>
                <span><?= $deliveryFee == 0 ? 'FREE' : 'R' . number_format($deliveryFee, 2) ?></span>
            </div>
            <div class="summary-row summary-total">
                <span>Total</span>
                <span>R<?= number_format($finalTotal, 2) ?></span>
            </div>

            <form method="POST" action="">
                <div class="delivery-address">
                    <label>Delivery Address *</label>
                    <textarea name="delivery_address" rows="3"
                              placeholder="Enter your full delivery address..." required></textarea>
                </div>
                <div class="payment-method">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="">Select payment method</option>
                        <option value="Credit Card">💳 Credit Card</option>
                        <option value="EFT">🏦 EFT / Bank Transfer</option>
                        <option value="SnapScan">📱 SnapScan</option>
                        <option value="Cash on Delivery">💵 Cash on Delivery</option>
                    </select>
                </div>
                <button type="submit" name="place_order" class="btn-place-order">✓ Place Order</button>
            </form>

            <p style="font-size:11px; color:var(--muted); text-align:center; margin-top:15px;">
                By placing your order, you agree to our terms and conditions.
            </p>
        </div>
    </div>

    <?php else: ?>
    <div class="cart-empty">
        <p style="font-size:3rem;">🛒</p>
        <p>Your cart is empty. Browse the listings and add something you love!</p>
        <a href="category.php" class="btn btn-primary">Browse Clothing</a>
    </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>

<!--
    ============================================================
    JAVASCRIPT — SellPrice popup trigger
    ============================================================
    TEACHING NOTE:
    When index.php redirects to cart.php?add=5&showpopup=1&price=X&name=Y,
    this script reads those URL parameters using URLSearchParams.
    If showpopup=1, it fills the popup with the item name and price
    then makes the overlay visible.
    closePopup() hides the overlay so the user sees the cart table.
-->
<script>
(function () {
    const params  = new URLSearchParams(window.location.search);
    const showPop = params.get('showpopup');
    const price   = params.get('price');
    const name    = params.get('name');

    if (showPop === '1' && price && name) {
        document.getElementById('popupPrice').textContent    = parseFloat(price).toFixed(2);
        document.getElementById('popupItemName').textContent = decodeURIComponent(name);
        const popup = document.getElementById('cartPopup');
        popup.style.display = 'flex';
    }
})();

function closePopup() {
    document.getElementById('cartPopup').style.display = 'none';
    window.history.replaceState({}, '', 'cart.php');
}
</script>
</body>
</html>