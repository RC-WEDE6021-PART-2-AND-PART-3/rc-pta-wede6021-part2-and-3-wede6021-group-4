<?php

/**
 * category.php
 * Pastimes — Product Category Page
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - This page displays all available clothing items from tblClothes.
 * - Accepts ?cat= parameter to filter products by category (Women, Men, Kids, etc.).
 * - Uses INNER JOIN with tblUser to display seller username for each product.
 * - Products are displayed in a responsive grid layout with images, brand, size, condition, and price.
 * - Add to Cart functionality is available for logged-in buyers only.
 * - If no products exist, shows a friendly empty state message.
 */
session_start();
require_once 'DBConn.php';

// Get category from URL
$category = isset($_GET['cat']) ? trim($_GET['cat']) : '';
$page_title = !empty($category) ? htmlspecialchars($category) : 'All Products';

// BUILD SQL QUERY USING YOUR EXACT COLUMN NAMES
$sql = "SELECT c.clothesID, c.brand, c.category, c.clothesSize, 
               c.conditionRating, c.price, c.description, c.imagePath,
               u.username AS sellerName
        FROM tblClothes c
        INNER JOIN tblUser u ON c.sellerID = u.userID
        WHERE c.clothesStatus = 'available'";

// Add category filter if specified
if (!empty($category)) {
    $sql .= " AND c.category = '" . mysqli_real_escape_string($conn, $category) . "'";
}

$sql .= " ORDER BY c.listedAt DESC";
$result = $conn->query($sql);
$item_count = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .category-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 1.5rem 2rem 3rem;
        }
        .breadcrumb {
            padding: 0 0 1.5rem 0;
            font-size: 13px;
            color: #8C8478;
        }
        .breadcrumb a {
            color: #8C8478;
            text-decoration: none;
        }
        .breadcrumb a:hover {
            color: #8B1A1A;
        }
        .breadcrumb .sep {
            margin: 0 5px;
        }
        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .category-title {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            font-weight: 700;
            color: #1C1C1A;
        }
        .category-count {
            color: #8C8478;
            font-size: 14px;
        }
        .section-heading {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #1C1C1A;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
        }
        .product-card {
            background: #FFFDF9;
            border: 1px solid #D4C4A8;
            border-radius: 16px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .product-card img {
            width: 100%;
            height: 220px;
            object-fit: cover;
        }
        .image-placeholder {
            height: 220px;
            background: linear-gradient(135deg, #f5eeed, #e8d5d0);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
        }
        .card-body {
            padding: 1rem;
        }
        .card-brand {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #8C8478;
            display: block;
            margin-bottom: 0.25rem;
        }
        .card-name {
            font-family: 'Playfair Display', serif;
            font-size: 16px;
            font-weight: 700;
            display: block;
            margin-bottom: 0.25rem;
            color: #1C1C1A;
        }
        .card-price {
            font-size: 18px;
            font-weight: 700;
            color: #8B1A1A;
            display: block;
            margin-bottom: 0.5rem;
        }
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            margin: 0.5rem 0;
        }
        .badge-excellent {
            background: #D1FAE5;
            color: #065F46;
        }
        .badge-good {
            background: #FEF3C7;
            color: #92400E;
        }
        .badge-fair {
            background: #FEE2E2;
            color: #991B1B;
        }
        .card-footer {
            padding: 0 1rem 1rem 1rem;
        }
        .btn-primary {
            display: block;
            text-align: center;
            background: #8B1A1A;
            color: #fff;
            text-decoration: none;
            padding: 10px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        .btn-primary:hover {
            background: #6b1414;
        }
        .btn-outline {
            display: block;
            text-align: center;
            background: transparent;
            border: 1px solid #8B1A1A;
            color: #8B1A1A;
            text-decoration: none;
            padding: 10px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
        }
        .alert-info {
            background: #FFFDF9;
            border: 1px solid #D4C4A8;
            border-radius: 16px;
            padding: 2rem;
            text-align: center;
            color: #8C8478;
        }
        .alert-info a {
            color: #8B1A1A;
            text-decoration: none;
        }
        @media (max-width: 900px) {
            .product-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 600px) {
            .product-grid { grid-template-columns: 1fr; }
            .category-container { padding: 1rem; }
            .category-title { font-size: 24px; }
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="category-container">
    <div class="breadcrumb">
        <a href="index.php">Home</a> <span class="sep">/</span>
        <span><?php echo $page_title; ?></span>
    </div>
    
    <div class="category-header">
        <div>
            <h1 class="category-title"><?php echo $page_title; ?></h1>
            <p class="category-count">Showing <?php echo $item_count; ?> items</p>
        </div>
    </div>

    <!-- PRODUCT LISTINGS -->
    <main id="listings">
        <h2 class="section-heading">Available Clothing</h2>

        <?php if ($result && $result->num_rows > 0): ?>
        <div class="product-grid">
            <?php while ($item = $result->fetch_assoc()): ?>
            <div class="product-card">
                <?php if (!empty($item['imagePath']) && file_exists($item['imagePath'])): ?>
                    <img src="<?= htmlspecialchars($item['imagePath']) ?>"
                         alt="<?= htmlspecialchars($item['brand']) ?> <?= htmlspecialchars($item['category']) ?>">
                <?php else: ?>
                    <div class="image-placeholder">👕</div>
                <?php endif; ?>

                <div class="card-body">
                    <span class="card-brand"><?= htmlspecialchars($item['brand']) ?></span>
                    <span class="card-name"><?= htmlspecialchars($item['category']) ?> — Size <?= htmlspecialchars($item['clothesSize']) ?></span>
                    <span class="card-price">R<?= number_format($item['price'], 2) ?></span>

                    <?php
                    $cond = $item['conditionRating'];
                    if ($cond === 'Excellent') {
                        $condClass = 'badge-excellent';
                    } elseif ($cond === 'Good') {
                        $condClass = 'badge-good';
                    } else {
                        $condClass = 'badge-fair';
                    }
                    ?>
                    <span class="badge <?= $condClass ?>"><?= $item['conditionRating'] ?></span>
                    <small style="display:block; color:#aaa; margin-top:5px;">Seller: @<?= htmlspecialchars($item['sellerName']) ?></small>
                </div>

                <div class="card-footer">
                    <?php if (isset($_SESSION['userID']) && ($_SESSION['role'] ?? '') === 'buyer'): ?>
                        <a href="cart.php?add=<?= $item['clothesID'] ?>&price=<?= $item['price'] ?>&name=<?= urlencode($item['brand'] . ' ' . $item['category']) ?>"
                           class="btn-primary">Add to Cart</a>
                    <?php elseif (!isset($_SESSION['userID'])): ?>
                        <a href="login.php" class="btn-outline">Login to Buy</a>
                    <?php else: ?>
                        <span style="font-size:0.8rem; color:#aaa;">Sellers cannot buy their own items</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <?php else: ?>
            <div class="alert-info">
                <p>No clothing items are currently listed.
                   <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'seller'): ?>
                       <a href="sell.php">Be the first to list an item!</a>
                   <?php else: ?>
                       Check back soon or <a href="register.php">register as a seller</a>.
                   <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
    </main>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>