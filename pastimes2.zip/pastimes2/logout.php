<?php
/**
 * logout.php
 * Pastimes - Logout
 * TEACHING NOTE:
 * session_destroy() removes ALL session data for this user.
 * session_unset() clears session variables first (good practice).
 * After destroying the session, redirect to homepage or login page.
 */
session_start();
session_unset();
session_destroy();
header("Location: login.php");
exit;
?>
