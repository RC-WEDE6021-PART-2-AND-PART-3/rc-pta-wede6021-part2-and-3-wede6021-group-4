<?php
/**
 * about.php
 * Pastimes — About Us Page
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Static informational page about the company.
 * - Explains the mission and environmental impact of second-hand fashion.
 * - Displays company stats: founded year, active listings, provinces covered.
 * - Includes call-to-action buttons linking to shop and sell pages.
 * - Button logic checks user role (buyer/seller/guest) for appropriate redirects.
 */
session_start();
require_once 'DBConn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .about-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem 2rem 4rem;
        }
        .breadcrumb {
            padding: 0 0 1.5rem 0;
            font-size: 13px;
            color: #8C8478;
        }
        .breadcrumb a {
            color: #8C8478;
            text-decoration: none;
        }
        .breadcrumb a:hover {
            color: #8B1A1A;
        }
        .breadcrumb .sep {
            margin: 0 5px;
        }
        .about-hero {
            text-align: center;
            margin-bottom: 3rem;
        }
        .about-tag {
            display: inline-block;
            background: rgba(139, 26, 26, 0.1);
            color: #8B1A1A;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-bottom: 1rem;
        }
        .about-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            font-weight: 700;
            line-height: 1.2;
            margin-bottom: 1rem;
            color: #1C1C1A;
        }
        .about-hero h1 em {
            color: #8B1A1A;
            font-style: italic;
        }
        .about-hero p {
            font-size: 16px;
            color: #8C8478;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.8;
        }
        .about-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 2rem;
            background: #1C1C1A;
            padding: 3rem;
            border-radius: 24px;
            text-align: center;
            margin-bottom: 3rem;
        }
        .stat-number {
            font-family: 'Playfair Display', serif;
            font-size: 40px;
            font-weight: 700;
            color: #fff;
            display: block;
            margin-bottom: 0.25rem;
        }
        .stat-label {
            font-size: 13px;
            color: #8C8478;
        }
        .about-section {
            margin-bottom: 3rem;
        }
        .about-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #1C1C1A;
        }
        .about-section p {
            font-size: 15px;
            color: #8C8478;
            line-height: 1.8;
            margin-bottom: 1rem;
        }
        .about-cta {
            background: #FAF7F2;
            border-radius: 20px;
            padding: 2.5rem;
            text-align: center;
            border: 1px solid #D4C4A8;
        }
        .about-cta h3 {
            font-family: 'Playfair Display', serif;
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #1C1C1A;
        }
        .about-cta p {
            font-size: 14px;
            color: #8C8478;
            margin-bottom: 1.5rem;
        }
        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
        }
        .btn-shop {
            background: #8B1A1A;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 12px 28px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s ease;
        }
        .btn-shop:hover {
            background: #6b1414;
        }
        .btn-sell {
            background: transparent;
            color: #1C1C1A;
            border: 1.5px solid #D4C4A8;
            border-radius: 10px;
            padding: 11px 27px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .btn-sell:hover {
            border-color: #8B1A1A;
            color: #8B1A1A;
        }
        @media (max-width: 768px) {
            .about-container { padding: 1.5rem 1.5rem 3rem; }
            .about-hero h1 { font-size: 36px; }
            .about-stats { grid-template-columns: 1fr; gap: 1.5rem; padding: 2rem; }
            .about-section h2 { font-size: 28px; }
            .about-cta h3 { font-size: 22px; }
            .cta-buttons { flex-direction: column; align-items: center; }
            .btn-shop, .btn-sell { width: 100%; max-width: 250px; text-align: center; }
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="about-container">
    <div class="breadcrumb">
        <a href="index.php">Home</a> <span class="sep">/</span>
        <span>About Us</span>
    </div>

    <div class="about-hero">
        <div class="about-tag">Our Story</div>
        <h1>FASHION BUILT FOR<br><em>THE NEXT GENERATION</em></h1>
        <p>Pastimes was born in South Africa out of frustration with fast fashion's price tags and environmental cost. We believe that great style shouldn't cost the earth — literally.</p>
    </div>

    <div class="about-stats">
        <div><span class="stat-number">2024</span><div class="stat-label">Founded in Pretoria</div></div>
        <div><span class="stat-number">5k+</span><div class="stat-label">Active listings</div></div>
        <div><span class="stat-number">9 provinces</span><div class="stat-label">Buyers &amp; sellers nationwide</div></div>
    </div>

    <div class="about-section">
        <h2>Why second-hand?</h2>
        <p>The fashion industry is one of the world's largest polluters. In South Africa, clothing and textiles make up a significant portion of landfill waste every year. By buying second-hand, you extend the life of a garment, reduce carbon emissions, and save money — often up to 80% off the original retail price.</p>
        <p>Pastimes makes this process simple, safe, and enjoyable. Our buyer protection program, verified sellers, and escrow payment system mean you can shop with complete confidence.</p>
    </div>

    <div class="about-cta">
        <h3>Ready to join the movement?</h3>
        <p>Browse thousands of pre-loved clothes, or clear out your wardrobe and earn today.</p>
        <div class="cta-buttons">
            <!-- SHOP NOW - takes to category.php (all categories) -->
            <a href="category.php" class="btn-shop">Shop Now</a>
            
            <!-- START SELLING - checks user role before going to sell page -->
            <?php if (isset($_SESSION['userID'])): ?>
                <?php if ($_SESSION['role'] == 'seller'): ?>
                    <!-- User is already a seller -->
                    <a href="sell.php" class="btn-sell">Start Selling</a>
                <?php elseif ($_SESSION['role'] == 'buyer'): ?>
                    <!-- User is a buyer - prompt to upgrade -->
                    <a href="#" class="btn-sell" onclick="alert('To sell items, you need to register as a seller. Please contact admin to upgrade your account.'); return false;">Start Selling</a>
                <?php else: ?>
                    <a href="register.php" class="btn-sell">Start Selling</a>
                <?php endif; ?>
            <?php else: ?>
                <!-- User not logged in - take to register page -->
                <a href="register.php" class="btn-sell">Start Selling</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>