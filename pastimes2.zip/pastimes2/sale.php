<?php
/**
 * sale.php
 * Pastimes — Sale Items Page
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Displays discounted items with sale badges showing discount percentages.
 * - Static page showcasing promotional products.
 * - Each product card includes Add to Cart button (visible to buyers only).
 * - Sellers see a message instead of Add to Cart button.
 * - Guests are prompted to login to make purchases.
 */
session_start();
require_once 'DBConn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .sale-container { max-width: 1300px; margin: 0 auto; padding: 1.5rem 2rem 3rem; }
        .breadcrumb { padding: 0 0 1.5rem; font-size: 13px; color: #8C8478; }
        .breadcrumb a { color: #8C8478; text-decoration: none; }
        .breadcrumb a:hover { color: #8B1A1A; }
        .breadcrumb .sep { margin: 0 5px; }
        .sale-header { text-align: center; margin-bottom: 2.5rem; }
        .sale-title { font-family: 'Playfair Display', serif; font-size: 42px; font-weight: 700; color: #8B1A1A; margin-bottom: 0.5rem; }
        .sale-subtitle { color: #8C8478; font-size: 16px; }
        .sale-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
        .sale-card { background: #FFFDF9; border: 1px solid #D4C4A8; border-radius: 16px; overflow: hidden; transition: transform 0.3s; position: relative; }
        .sale-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .sale-badge { position: absolute; top: 12px; left: 12px; background: #8B1A1A; color: #fff; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 20px; }
        .sale-image { height: 220px; background: #FAF7F2; display: flex; align-items: center; justify-content: center; font-size: 4rem; }
        .sale-info { padding: 1rem; }
        .sale-info h3 { font-family: 'Playfair Display', serif; font-size: 16px; font-weight: 700; margin-bottom: 0.25rem; }
        .sale-info .brand { font-size: 12px; color: #8C8478; margin-bottom: 0.5rem; }
        .price-group { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; }
        .current-price { font-size: 18px; font-weight: 700; color: #8B1A1A; }
        .original-price { font-size: 13px; color: #8C8478; text-decoration: line-through; }
        .btn-add-cart { display: block; text-align: center; background: #8B1A1A; color: #fff; text-decoration: none; padding: 10px; border-radius: 8px; font-size: 13px; }
        .btn-add-cart:hover { background: #6b1414; }
        @media (max-width: 900px) { .sale-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 600px) { .sale-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="sale-container">
    <div class="breadcrumb">
        <a href="index.php">Home</a> <span class="sep">/</span>
        <span>Sale</span>
    </div>
    
    <div class="sale-header">
        <h1 class="sale-title">SALE</h1>
        <p class="sale-subtitle">Up to 70% off on selected items</p>
    </div>
    
    <div class="sale-grid">
        <?php 
        $sale_items = [
            ['name' => 'Classic Denim Shirt', 'brand' => 'Levi\'s', 'price' => 195, 'original' => 699, 'discount' => '-72%', 'icon' => '👕'],
            ['name' => 'Urban Tech Hoodie', 'brand' => 'Superdry', 'price' => 260, 'original' => 899, 'discount' => '-65%', 'icon' => '🧥'],
            ['name' => 'Ultraboost 22', 'brand' => 'Adidas', 'price' => 540, 'original' => 2200, 'discount' => '-75%', 'icon' => '👟'],
            ['name' => 'Sport Sunglasses', 'brand' => 'Oakley', 'price' => 380, 'original' => 950, 'discount' => '-60%', 'icon' => '🕶️'],
            ['name' => 'Floral Wrap Dress', 'brand' => 'Zara', 'price' => 185, 'original' => 370, 'discount' => '-50%', 'icon' => '👗'],
            ['name' => 'Padded Backpack', 'brand' => 'Eastpak', 'price' => 290, 'original' => 645, 'discount' => '-55%', 'icon' => '🎒'],
        ];
        foreach ($sale_items as $item): ?>
        <div class="sale-card">
            <div class="sale-badge"><?php echo $item['discount']; ?></div>
            <div class="sale-image"><?php echo $item['icon']; ?></div>
            <div class="sale-info">
                <h3><?php echo $item['name']; ?></h3>
                <p class="brand"><?php echo $item['brand']; ?></p>
                <div class="price-group">
                    <span class="current-price">R<?php echo number_format($item['price'], 2); ?></span>
                    <span class="original-price">R<?php echo number_format($item['original'], 2); ?></span>
                </div>
                <a href="cart.php?add=<?php echo rand(1, 10); ?>" class="btn-add-cart">Add to Cart</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
</body>
</html>