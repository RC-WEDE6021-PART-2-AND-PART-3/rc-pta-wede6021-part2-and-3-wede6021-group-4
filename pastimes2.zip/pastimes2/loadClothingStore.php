<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// FIRST CONNECT WITHOUT A DATABASE (to create it)
$conn = new mysqli('127.0.0.1', 'root', '', '', 3306);

if ($conn->connect_error) {
    die("<p style='color:red'>Failed: " . $conn->connect_error . "</p>");
}
echo "<p style='color:green'>Connected to MySQL server!</p>";

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS ClothingStore";
if ($conn->query($sql)) {
    echo "<p style='color:green'>Database 'ClothingStore' is ready</p>";
} else {
    die("<p style='color:red'>Failed to create database: " . $conn->error . "</p>");
}

// NOW connect to the database
$conn = new mysqli('127.0.0.1', 'root', '', 'ClothingStore', 3306);
if ($conn->connect_error) {
    die("<p style='color:red'>Failed to connect to database: " . $conn->connect_error . "</p>");
}
echo "<p style='color:green'>Connected to ClothingStore database!</p>";

$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DROP TABLE IF EXISTS tblOrder");
$conn->query("DROP TABLE IF EXISTS tblClothes");
$conn->query("DROP TABLE IF EXISTS tblAdmin");
$conn->query("DROP TABLE IF EXISTS tblUser");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");
echo "<p style='color:orange'>Old tables cleared</p>";

$tables = array(
"tblUser" => "CREATE TABLE tblUser (
    userID INT(11) AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    userPassword VARCHAR(255) NOT NULL,
    userRole ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
    sellerStatus ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
    status ENUM('active', 'suspended', 'pending') DEFAULT 'active',
    deliveryAddr TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
)",
"tblAdmin" => "CREATE TABLE tblAdmin (
    adminID INT(11) AUTO_INCREMENT PRIMARY KEY,
    userID INT(11) NOT NULL,
    adminLevel ENUM('super','standard') NOT NULL DEFAULT 'standard',
    lastLogin DATETIME,
    FOREIGN KEY (userID) REFERENCES tblUser(userID) ON DELETE CASCADE
)",
"tblClothes" => "CREATE TABLE tblClothes (
    clothesID INT(11) AUTO_INCREMENT PRIMARY KEY,
    sellerID INT(11) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    clothesSize VARCHAR(20) NOT NULL,
    conditionRating ENUM('Excellent','Good','Fair','Like new') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    originalPrice DECIMAL(10,2) DEFAULT NULL,
    description TEXT,
    imagePath VARCHAR(255),
    clothesStatus ENUM('available','sold','pending') NOT NULL DEFAULT 'available',
    listedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sellerID) REFERENCES tblUser(userID) ON DELETE CASCADE
)",
"tblOrder" => "CREATE TABLE tblOrder (
    orderID INT(11) AUTO_INCREMENT PRIMARY KEY,
    buyerID INT(11) NOT NULL,
    clothesID INT(11) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    orderStatus ENUM('pending','confirmed','in-transit','delivered','cancelled') NOT NULL DEFAULT 'pending',
    deliveryAddr TEXT NOT NULL,
    payment_method VARCHAR(50) DEFAULT NULL,
    orderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyerID) REFERENCES tblUser(userID) ON DELETE CASCADE,
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID) ON DELETE CASCADE
)"
);

foreach ($tables as $name => $sql) {
    if ($conn->query($sql)) {
        echo "<p style='color:green'>$name created</p>";
    } else {
        echo "<p style='color:red'>$name failed: ".$conn->error."</p>";
    }
}

// ============================================================
// INSERT USERS
// ============================================================
$users = array(
    array('John Doe',      'j.doe@abc.co.za',      'johndoe',    'password1',  'buyer',  'verified'),
    array('Jane Smith',    'j.smith@gmail.com',     'janesmith',  'password2',  'seller', 'pending'),
    array('Thabo Nkosi',   't.nkosi@webmail.co.za', 'thabonkosi', 'password3',  'buyer',  'verified'),
    array('Amara Dlamini', 'a.dlamini@yahoo.com',   'amarad',     'password4',  'seller', 'pending'),
    array('Sipho Mokoena', 's.mokoena@outlook.com', 'siphom',     'password5',  'buyer',  'verified'),
    array('Admin User',    'admin@pastimes.co.za',  'adminuser',  'Admin@1234', 'admin',  'verified')
);

foreach ($users as $u) {
    $hashed = password_hash($u[3], PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO tblUser (fullName, email, username, userPassword, userRole, sellerStatus, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
    $stmt->bind_param("ssssss", $u[0], $u[1], $u[2], $hashed, $u[4], $u[5]);
    if ($stmt->execute()) {
        echo "<p style='color:green'>Added user: ".$u[0]." (".$u[4].")</p>";
    } else {
        echo "<p style='color:orange'>Skipped ".$u[0].": ".$stmt->error."</p>";
    }
    $stmt->close();
}

// Insert admin link
$conn->query("INSERT INTO tblAdmin (userID,adminLevel) SELECT userID,'super' FROM tblUser WHERE username='adminuser' LIMIT 1");
echo "<p style='color:green'>Admin linked</p>";

// ============================================================
// INSERT SAMPLE PRODUCTS
// ============================================================
echo "<hr><h3>Inserting Sample Products...</h3>";

// Get seller IDs
$janesmith_id = $conn->query("SELECT userID FROM tblUser WHERE username='janesmith'")->fetch_assoc()['userID'] ?? 0;
$amarad_id = $conn->query("SELECT userID FROM tblUser WHERE username='amarad'")->fetch_assoc()['userID'] ?? 0;
$johndoe_id = $conn->query("SELECT userID FROM tblUser WHERE username='johndoe'")->fetch_assoc()['userID'] ?? 0;

$products = array(
    // Women's Clothing
    array($janesmith_id, 'Levi\'s', 'Women', 'M', 'Excellent', 320.00, 1100.00, 'Classic vintage denim jacket in great condition.', '', 'available'),
    array($amarad_id, 'Zara', 'Women', 'S', 'Excellent', 185.00, 699.00, 'Beautiful floral print dress, worn only once.', '', 'available'),
    array($johndoe_id, 'H&M', 'Women', 'L', 'Good', 95.00, 280.00, 'Casual summer dress, lightly worn.', '', 'available'),
    
    // Men's Clothing
    array($janesmith_id, 'Superdry', 'Men', 'L', 'Good', 260.00, 899.00, 'Comfortable fleece hoodie, minor fading.', '', 'available'),
    array($amarad_id, 'Tommy Hilfiger', 'Men', 'M', 'Excellent', 145.00, 450.00, 'Slim fit polo shirt, like new.', '', 'available'),
    array($johndoe_id, 'Nike', 'Men', 'XL', 'Excellent', 220.00, 800.00, 'Sport jacket, never worn.', '', 'available'),
    
    // Kids Clothing
    array($janesmith_id, 'Disney', 'Kids', 'S', 'Excellent', 65.00, 150.00, 'Mickey Mouse t-shirt, like new.', '', 'available'),
    array($amarad_id, 'Nike', 'Kids', 'M', 'Good', 120.00, 350.00, 'Kids sneakers, lightly worn.', '', 'available'),
    
    // Shoes
    array($janesmith_id, 'Nike', 'Shoes', 'UK 8', 'Excellent', 480.00, 1599.00, 'Nike Air Force 1 Low White, like new.', '', 'available'),
    array($amarad_id, 'Adidas', 'Shoes', 'UK 9', 'Excellent', 540.00, 2200.00, 'Ultraboost running shoes.', '', 'available'),
    array($johndoe_id, 'Converse', 'Shoes', 'UK 7', 'Good', 320.00, 800.00, 'Classic Chuck Taylor All Star.', '', 'available'),
    
    // Accessories
    array($janesmith_id, 'Polaroid', 'Accessories', 'One size', 'Good', 110.00, 250.00, 'Retro sunglasses with case.', '', 'available'),
    array($amarad_id, 'Gucci', 'Accessories', 'One size', 'Excellent', 680.00, 1200.00, 'Designer scarf, authentic.', '', 'available'),
    array($johndoe_id, 'Fjällräven', 'Accessories', 'One size', 'Excellent', 450.00, 900.00, 'Kånken mini backpack.', '', 'available'),
    
    // Vintage
    array($janesmith_id, 'Vintage Levi\'s', 'Vintage', '30', 'Good', 350.00, 850.00, 'Vintage 501 jeans, 90s style.', '', 'available'),
    array($amarad_id, 'Vintage Nike', 'Vintage', 'M', 'Fair', 180.00, 450.00, 'Retro Nike windbreaker.', '', 'available'),
);

$productCount = 0;
foreach ($products as $p) {
    $stmt = $conn->prepare("INSERT INTO tblClothes (sellerID, brand, category, clothesSize, conditionRating, price, originalPrice, description, imagePath, clothesStatus, listedAt) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("issssddsss", $p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6], $p[7], $p[8], $p[9]);
    if ($stmt->execute()) {
        $productCount++;
        echo "<p style='color:green'>Added product: " . $p[1] . " - " . $p[2] . " (R" . $p[5] . ")</p>";
    } else {
        echo "<p style='color:orange'>Failed: " . $p[1] . " - " . $stmt->error . "</p>";
    }
    $stmt->close();
}

// ============================================================
// INSERT SAMPLE ORDERS
// ============================================================
echo "<hr><h3>Inserting Sample Orders...</h3>";

$buyer_id = $conn->query("SELECT userID FROM tblUser WHERE username='johndoe'")->fetch_assoc()['userID'] ?? 0;
$clothes_ids = $conn->query("SELECT clothesID, price FROM tblClothes LIMIT 3");

$orderCount = 0;
while ($clothes = $clothes_ids->fetch_assoc()) {
    $stmt = $conn->prepare("INSERT INTO tblOrder (buyerID, clothesID, total_amount, orderStatus, deliveryAddr, payment_method, orderDate) 
                            VALUES (?, ?, ?, 'pending', '123 Main Street, Johannesburg', 'Credit Card', NOW())");
    $stmt->bind_param("iid", $buyer_id, $clothes['clothesID'], $clothes['price']);
    if ($stmt->execute()) {
        $orderCount++;
        echo "<p style='color:green'>Added order for product ID: " . $clothes['clothesID'] . "</p>";
    }
    $stmt->close();
}

// ============================================================
// DISPLAY SUMMARY
// ============================================================
echo "<hr>";
echo "<h2 style='color:green'>✅ ALL DONE! Database is ready.</h2>";
echo "<p><strong>📊 Summary:</strong></p>";
echo "<ul>";
echo "<li>✓ Database 'ClothingStore' created</li>";
echo "<li>✓ Users inserted: " . count($users) . "</li>";
echo "<li>✓ Products inserted: " . $productCount . "</li>";
echo "<li>✓ Orders inserted: " . $orderCount . "</li>";
echo "</ul>";

echo "<p><strong>🔐 Login Credentials:</strong></p>";
echo "<ul>";
echo "<li><strong>Admin:</strong> username='adminuser', password='Admin@1234'</li>";
echo "<li><strong>Buyer:</strong> email='john@example.com', password='password1'</li>";
echo "<li><strong>Seller:</strong> email='jane@example.com', password='password2' (Pending)</li>";
echo "</ul>";

echo "<hr>";
echo "<p><a href='index.php' style='background:#8B1A1A; color:white; padding:10px 20px; text-decoration:none; border-radius:8px;'>Go to Website →</a></p>";

$conn->close();
?>