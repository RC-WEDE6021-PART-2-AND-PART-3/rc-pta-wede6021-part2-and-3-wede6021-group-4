<?php
/**
 * createTable.php
 * Pastimes - Create and populate tblUser from userData.txt
 * Student: Emihle Zifo (ST10452317) & Mzukisi Tekeni (ST10345918)
 * WEDE6021POE
 *
 * PURPOSE:
 * 1. Checks if tblUser exists; if it does, DELETE it.
 * 2. RE-CREATE tblUser with all required columns.
 * 3. LOAD data from userData.txt into the table.
 *
 * TEACHING NOTE:
 * This file uses require_once to include DBConn.php.
 * Every time this script runs, the table is reset and reloaded.
 * This is useful for testing and resetting the database to a known state.
 */

// Include the database connection file
require_once 'DBConn.php';

// ============================================================
// STEP 1: DROP tblUser if it already exists
// ============================================================
/**
 * TEACHING NOTE:
 * We temporarily disable foreign key checks before dropping tblUser.
 * This is necessary because other tables (e.g. tblOrder, tblClothes) have
 * foreign keys that reference tblUser. Without this, MySQL refuses to drop it.
 * We re-enable foreign key checks immediately after the drop.
 */
$conn->query("SET FOREIGN_KEY_CHECKS = 0");

$dropSQL = "DROP TABLE IF EXISTS tblUser";
if ($conn->query($dropSQL) === TRUE) {
    echo "<p style='color:orange;'>✓ Old tblUser dropped (or did not exist).</p>";
} else {
    echo "<p style='color:red;'>✗ Error dropping table: " . $conn->error . "</p>";
}

$conn->query("SET FOREIGN_KEY_CHECKS = 1");

// ============================================================
// STEP 2: CREATE tblUser
// ============================================================
/**
 * TEACHING NOTE:
 * INT AUTO_INCREMENT = automatically increases the ID by 1 for each new row.
 * PRIMARY KEY = uniquely identifies each row.
 * VARCHAR(n) = variable-length string with max n characters.
 * ENUM = only allows the listed values.
 * DEFAULT = sets a value automatically if none is provided.
 * password_hash() in PHP uses bcrypt, producing a 255-character string.
 * seller_status tracks whether the admin has approved a seller.
 */
$createSQL = "CREATE TABLE tblUser (
    userID        INT(11) AUTO_INCREMENT PRIMARY KEY,
    fullName      VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    userPassword  VARCHAR(255) NOT NULL,
    userRole      ENUM('buyer','seller','admin') DEFAULT 'buyer',
    sellerStatus  ENUM('pending','verified','rejected') DEFAULT 'pending',
    deliveryAddr  TEXT,
    createdAt     DATETIME DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($createSQL) === TRUE) {
    echo "<p style='color:green;'>✓ tblUser created successfully.</p>";
} else {
    echo "<p style='color:red;'>✗ Error creating table: " . $conn->error . "</p>";
}

// ============================================================
// STEP 3: LOAD DATA from userData.txt
// ============================================================
/**
 * TEACHING NOTE:
 * file() reads a file into an array — one element per line.
 * FILE_IGNORE_NEW_LINES removes newline characters at the end of each line.
 * FILE_SKIP_EMPTY_LINES skips blank lines.
 * explode("\t", $line) splits by TAB character (our file uses tab separation).
 *
 * The admin email is detected and given userRole = 'admin' automatically.
 * All others default to 'buyer'.
 */
$filePath = __DIR__ . '/userData.txt';

if (!file_exists($filePath)) {
    echo "<p style='color:red;'>✗ userData.txt not found at: $filePath</p>";
    exit;
}

$lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$insertCount = 0;

foreach ($lines as $line) {
    // Each line: fullName [TAB] email [TAB] username [TAB] hashedPassword
    $parts = explode("\t", $line);

    if (count($parts) < 4) {
        echo "<p style='color:orange;'>⚠ Skipping malformed line: $line</p>";
        continue;
    }

    $fullName = trim($parts[0]);
    $email    = trim($parts[1]);
    $username = trim($parts[2]);
    $password = trim($parts[3]);

    // Set role to 'admin' for the admin account, 'buyer' for everyone else
    $role = ($email === 'admin@pastimes.co.za') ? 'admin' : 'buyer';

    /**
     * TEACHING NOTE:
     * We use a Prepared Statement here. This is CRITICAL for security.
     * Instead of inserting values directly into the SQL string (which allows
     * SQL Injection attacks), we use ? placeholders and bind the actual values.
     * bind_param("sssss", ...) means: 5 string parameters.
     */
    $stmt = $conn->prepare(
        "INSERT INTO tblUser (fullName, email, username, userPassword, userRole) VALUES (?, ?, ?, ?, ?)"
    );

    if ($stmt === false) {
        echo "<p style='color:red;'>✗ Prepare failed: " . $conn->error . "</p>";
        continue;
    }

    $stmt->bind_param("sssss", $fullName, $email, $username, $password, $role);

    if ($stmt->execute()) {
        $insertCount++;
        echo "<p style='color:green;'>✓ Inserted user: <strong>$fullName</strong> ($email) — Role: <strong>$role</strong></p>";
    } else {
        echo "<p style='color:red;'>✗ Error inserting $fullName: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

echo "<hr>";
echo "<p><strong>Total users loaded: $insertCount</strong></p>";
echo "<p><a href='index.php'>← Back to Homepage</a></p>";

// Close the database connection
$conn->close();
?>