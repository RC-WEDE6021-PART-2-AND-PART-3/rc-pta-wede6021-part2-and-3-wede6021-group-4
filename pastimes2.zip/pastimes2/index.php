<?php
/**
 * index.php
 * Pastimes — Homepage & Product Listing
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - This page serves as the main landing page of the website.
 * - Displays hero section with dynamic stats (items listed, buyers, sold items).
 * - Shows all available clothing items fetched from tblClothes using fetch_assoc().
 * - INNER JOIN links tblClothes to tblUser to display the seller's username.
 * - session_start() enables user session tracking for login status.
 * - Add to Cart button only shows for logged-in buyers.
 */

session_start();
require_once 'DBConn.php';

// ============================================================
// FETCH ALL AVAILABLE CLOTHING ITEMS (with seller info via JOIN)
// ============================================================
/**
 * TEACHING NOTE: SQL JOIN
 * tblClothes alone does not contain the seller's name — that is in tblUser.
 * INNER JOIN tblUser ON tblClothes.sellerID = tblUser.userID
 * merges the two tables so we get both clothing AND seller data in one query.
 * We only show items where clothesStatus = 'available' (not yet sold).
 */
$sql = "SELECT c.clothesID, c.brand, c.category, c.clothesSize,
               c.conditionRating, c.price, c.description, c.imagePath,
               u.username AS sellerName
        FROM tblClothes c
        INNER JOIN tblUser u ON c.sellerID = u.userID
        WHERE c.clothesStatus = 'available'
        ORDER BY c.listedAt DESC";

$result = $conn->query($sql);

// Fetch stats for hero section
$statsItems  = $conn->query("SELECT COUNT(*) as c FROM tblClothes WHERE clothesStatus='available'")->fetch_assoc()['c'] ?? 0;
$statsBuyers = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole='buyer'")->fetch_assoc()['c'] ?? 0;
$statsSold   = $conn->query("SELECT COUNT(*) as c FROM tblClothes WHERE clothesStatus='sold'")->fetch_assoc()['c'] ?? 0;

// ============================================================
// FETCH CATEGORY COUNTS
// ============================================================
$categories = ['Women' => 0, 'Men' => 0, 'Kids' => 0, 'Shoes' => 0, 'Vintage' => 0, 'Accessories' => 0];
$catQuery = $conn->query("SELECT category, COUNT(*) as count FROM tblClothes WHERE clothesStatus='available' GROUP BY category");
while ($cat = $catQuery->fetch_assoc()) {
    if (isset($categories[$cat['category']])) {
        $categories[$cat['category']] = $cat['count'];
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pastimes — Pre-Loved Branded Clothing</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/script.js" defer></script>
    <style>
        /* ── Available Clothing Section ── */
        .listings-section {
            max-width: 1300px;
            margin: 0 auto;
            padding: 3rem 2rem;
        }
        .listings-section h2 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            color: #1C1C1A;
            margin-bottom: 0.4rem;
        }
        .listings-section p.sub {
            color: #8C8478;
            font-size: 14px;
            margin-bottom: 2rem;
        }
        .clothes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.5rem;
        }
        .clothes-card {
            background: #fff;
            border: 1px solid #E8E0D8;
            border-radius: 12px;
            overflow: hidden;
            transition: box-shadow 0.2s;
        }
        .clothes-card:hover {
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .clothes-card img {
            width: 100%;
            height: 220px;
            object-fit: cover;
        }
        .clothes-card-placeholder {
            width: 100%;
            height: 220px;
            background: linear-gradient(135deg, #f5eeed, #e8d5d0);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
        }
        .clothes-card-body {
            padding: 1rem;
        }
        .clothes-card-brand {
            font-weight: 700;
            font-size: 15px;
            color: #1C1C1A;
        }
        .clothes-card-cat {
            font-size: 13px;
            color: #8C8478;
            margin-top: 2px;
        }
        .clothes-card-price {
            font-size: 18px;
            font-weight: 700;
            color: #8B1A1A;
            margin-top: 8px;
        }
        .clothes-card-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 6px;
            font-size: 12px;
            color: #8C8478;
        }
        .clothes-card-footer {
            padding: 0 1rem 1rem;
        }
        .btn-cart {
            display: block;
            width: 100%;
            background: #8B1A1A;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: background 0.2s;
            font-family: inherit;
        }
        .btn-cart:hover { background: #6b1414; color: #fff; }
        .btn-login-to-buy {
            display: block;
            width: 100%;
            background: transparent;
            color: #8B1A1A;
            border: 1px solid #8B1A1A;
            padding: 10px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            transition: background 0.2s;
        }
        .btn-login-to-buy:hover {
            background: #8B1A1A;
            color: #fff;
        }
        .badge-condition {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }
        .badge-excellent { background: #D1FAE5; color: #065F46; }
        .badge-good      { background: #DBEAFE; color: #1E40AF; }
        .badge-fair      { background: #FEF3C7; color: #92400E; }

        /* Popup overlay */
        .popup-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.45);
            z-index: 999;
            align-items: center;
            justify-content: center;
        }
        .popup-overlay.active { display: flex; }
        .popup-box {
            background: #fff;
            border-radius: 12px;
            padding: 36px 40px;
            max-width: 380px;
            width: 90%;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0,0,0,0.18);
            animation: popIn 0.2s ease;
        }
        @keyframes popIn {
            from { transform: scale(0.85); opacity: 0; }
            to   { transform: scale(1);   opacity: 1; }
        }
        .popup-icon { font-size: 2.8rem; margin-bottom: 12px; }
        .popup-title { font-size: 1.15rem; font-weight: 700; color: #8B1A1A; margin-bottom: 6px; }
        .popup-item-name { color: #8C8478; font-size: 0.9rem; margin-bottom: 18px; }
        .popup-price { font-size: 2rem; font-weight: 900; color: #8B1A1A; margin-bottom: 22px; }
        .popup-price small { font-size: 1rem; font-weight: 400; color: #8C8478; display: block; margin-bottom: 4px; }
        .popup-close { width: 100%; background: #8B1A1A; color: #fff; border: none; padding: 12px; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; font-family: inherit; }
        .popup-close:hover { background: #6b1414; }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<!-- ============================================================ -->
<!-- PRICE POPUP OVERLAY -->
<!-- Shown when Add to Cart is clicked — displays SellPrice       -->
<!-- ============================================================ -->
<div class="popup-overlay" id="cartPopup">
    <div class="popup-box">
        <div class="popup-icon">🛒</div>
        <div class="popup-title">Added to Cart!</div>
        <div class="popup-item-name" id="popupItemName"></div>
        <div class="popup-price">
            <small>Sell Price</small>
            R<span id="popupPrice">0.00</span>
        </div>
        <!--
            TEACHING NOTE: Return to Table
            Clicking this button hides the popup so the user
            sees the product listings table again.
        -->
        <button class="popup-close" onclick="closePopup()">← Return to Table</button>
    </div>
</div>

<!-- ============================================================ -->
<!-- HERO SECTION -->
<!-- ============================================================ -->
<section class="intro-banner">
  <div class="intro-inner">
    <div class="intro-text">
      <h1 class="intro-heading">Pre-loved fashion<br>for South Africa.</h1>
      <p class="intro-sub">Buy and sell quality second-hand clothing — sustainably, safely, and affordably.</p>
      <div class="intro-actions">
        <a href="category.php" class="btn-rust">Browse clothes</a>
        <a href="sell.php" class="btn-outline-light">Sell your items</a>
      </div>
    </div>
    <div class="intro-stats">
      <div class="intro-stat">
        <span class="is-num"><?php echo $statsItems; ?></span>
        <span class="is-lbl">Items listed</span>
      </div>
      <div class="intro-divider"></div>
      <div class="intro-stat">
        <span class="is-num"><?php echo $statsBuyers; ?></span>
        <span class="is-lbl">Happy buyers</span>
      </div>
      <div class="intro-divider"></div>
      <div class="intro-stat">
        <span class="is-num"><?php echo $statsSold; ?></span>
        <span class="is-lbl">Items sold</span>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================ -->
<!-- CATEGORIES SECTION -->
<!-- ============================================================ -->
<div class="section">
  <div class="sec-head">
    <h2 class="sec-title">Browse by Category</h2>
    <a href="category.php" class="sec-link">View all categories →</a>
  </div>
  <div class="home-cat-grid">
    <a href="category.php?cat=Women" class="home-cat-card">
      <img src="images/Rectangle 47.png" alt="Women" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Women</div>
        <div class="cat-count"><?php echo number_format($categories['Women']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
    <a href="category.php?cat=Men" class="home-cat-card">
      <img src="images/Category Card.png" alt="Men" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Men</div>
        <div class="cat-count"><?php echo number_format($categories['Men']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
    <a href="category.php?cat=Kids" class="home-cat-card">
      <img src="images/kid.png" alt="Kids" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Kids</div>
        <div class="cat-count"><?php echo number_format($categories['Kids']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
    <a href="category.php?cat=Shoes" class="home-cat-card">
      <img src="images/Shoes.png" alt="Shoes" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Shoes</div>
        <div class="cat-count"><?php echo number_format($categories['Shoes']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
    <a href="category.php?cat=Vintage" class="home-cat-card">
      <img src="images/Vintage.png" alt="Vintage" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Vintage</div>
        <div class="cat-count"><?php echo number_format($categories['Vintage']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
    <a href="category.php?cat=Accessories" class="home-cat-card">
      <img src="images/Accessories.png" alt="Accessories" class="cat-img">
      <div class="cat-overlay">
        <div class="cat-name">Accessories</div>
        <div class="cat-count"><?php echo number_format($categories['Accessories']); ?> items available</div>
      </div>
      <div class="cat-arrow"><svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div>
    </a>
  </div>
</div>

<!-- ============================================================ -->
<!-- HOW IT WORKS -->
<!-- ============================================================ -->
<section style="background:#fff; padding:3rem 2rem; text-align:center; border-bottom:1px solid #eee;">
    <h2 style="font-family:'Playfair Display', serif; font-size:28px; color:#1C1C1A; margin-bottom:0.5rem;">How Pastimes Works</h2>
    <p style="font-size:14px; color:#8C8478; margin-bottom:2.5rem;">Simple, safe, and sustainable fashion exchange.</p>
    <div style="display:flex; gap:2rem; justify-content:center; flex-wrap:wrap; max-width:1000px; margin:0 auto;">
        <?php foreach([
            ['1','Browse & Discover','Explore pre-loved branded items filtered by brand, size, and condition.'],
            ['2','Add to Cart','Found something you love? Add it and pay securely through our platform.'],
            ['3','Delivered to You','The seller ships to you via courier within 2–4 business days.'],
            ['4','Confirm & Rate','Confirm receipt, release payment, and leave a review.'],
        ] as [$num,$title,$desc]): ?>
        <div style="max-width:220px;">
            <div style="width:48px;height:48px;background:#8B1A1A;color:#fff;border-radius:50%;
                        display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;
                        font-family:'Playfair Display',serif;font-size:20px;font-weight:700;"><?= $num ?></div>
            <strong style="font-size:15px;color:#1C1C1A;"><?= $title ?></strong>
            <p style="font-size:13px;color:#8C8478;margin-top:0.5rem;line-height:1.6;"><?= $desc ?></p>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ============================================================ -->
<!-- AVAILABLE CLOTHING — tbl_Item read into assoc array          -->
<!-- Displayed in tabular format with headers per rubric          -->
<!-- ============================================================ -->
<section class="listings-section" id="listings">
    <h2>Available Clothing</h2>
    <p class="sub">All items are pre-loved, quality-checked, and ready to ship.</p>

    <?php if ($result && $result->num_rows > 0): ?>
    <div class="clothes-grid">
        <?php while ($item = $result->fetch_assoc()): ?>
        <div class="clothes-card">

            <!-- PICTURE column — satisfies rubric: "each line contains picture of item" -->
            <?php if (!empty($item['imagePath']) && file_exists($item['imagePath'])): ?>
                <img src="<?= htmlspecialchars($item['imagePath']) ?>"
                     alt="<?= htmlspecialchars($item['brand']) ?>">
            <?php else: ?>
                <div class="clothes-card-placeholder">👗</div>
            <?php endif; ?>

            <div class="clothes-card-body">
                <div class="clothes-card-brand"><?= htmlspecialchars($item['brand']) ?></div>
                <div class="clothes-card-cat"><?= htmlspecialchars($item['category']) ?> — Size <?= htmlspecialchars($item['clothesSize']) ?></div>
                <div class="clothes-card-price">R<?= number_format($item['price'], 2) ?></div>
                <div class="clothes-card-meta">
                    <?php
                    $cond = $item['conditionRating'];
                    if ($cond === 'Excellent' || $cond === 'Like new') {
                        $badgeClass = 'badge-excellent';
                    } elseif ($cond === 'Good') {
                        $badgeClass = 'badge-good';
                    } else {
                        $badgeClass = 'badge-fair';
                    }
                    ?>
                    <span class="badge-condition <?= $badgeClass ?>"><?= htmlspecialchars($cond) ?></span>
                    <span>@<?= htmlspecialchars($item['sellerName']) ?></span>
                </div>
            </div>

            <div class="clothes-card-footer">
                <!--
                    TEACHING NOTE: Add to Cart button
                    Only logged-in buyers see the Add to Cart button.
                    $_SESSION['role'] is set in login.php when the user logs in.
                    The link passes clothesID, price and name to cart.php via GET.
                    cart.php then adds the item to the PHP SESSION cart array
                    and shows a popup with the SellPrice.
                -->
                <?php if (isset($_SESSION['userID']) && ($_SESSION['role'] ?? '') === 'buyer'): ?>
                    <a href="cart.php?add=<?= $item['clothesID'] ?>&showpopup=1&price=<?= $item['price'] ?>&name=<?= urlencode($item['brand'] . ' ' . $item['category']) ?>"
                       class="btn-cart">🛒 Add to Cart</a>

                <?php elseif (!isset($_SESSION['userID'])): ?>
                    <a href="login.php" class="btn-login-to-buy">Login to Buy</a>

                <?php else: ?>
                    <span style="font-size:12px; color:#8C8478;">Not available for this account</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <?php else: ?>
        <p style="color:#8C8478; text-align:center; padding:3rem;">
            No clothing items are currently listed.
            <?php if (($_SESSION['role'] ?? '') === 'seller' && ($_SESSION['status'] ?? '') === 'verified'): ?>
                <a href="sell.php">Be the first to list an item!</a>
            <?php endif; ?>
        </p>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>

<!--
    ============================================================
    JAVASCRIPT — SellPrice popup trigger
    ============================================================
    TEACHING NOTE:
    When cart.php redirects back with ?showpopup=1&price=X&name=Y,
    this script reads those URL parameters using URLSearchParams.
    It fills the popup with the item name and price, then shows it.
    closePopup() hides the overlay so the user sees the table again.
-->
<script>
(function () {
    const params  = new URLSearchParams(window.location.search);
    const showPop = params.get('showpopup');
    const price   = params.get('price');
    const name    = params.get('name');

    if (showPop === '1' && price && name) {
        document.getElementById('popupPrice').textContent    = parseFloat(price).toFixed(2);
        document.getElementById('popupItemName').textContent = decodeURIComponent(name);
        document.getElementById('cartPopup').classList.add('active');
    }
})();

function closePopup() {
    document.getElementById('cartPopup').classList.remove('active');
    window.history.replaceState({}, '', 'index.php');
}
</script>

</body>
</html>