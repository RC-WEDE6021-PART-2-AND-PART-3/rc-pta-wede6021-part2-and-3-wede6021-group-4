<?php
/**
 * DBConn.php
 * Pastimes — Database Connection File
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Establishes connection to MySQL database 'ClothingStore'.
 * - Uses MySQLi object-oriented approach for better security.
 * - Connection parameters: localhost, root, empty password.
 * - Sets UTF-8 charset for proper handling of special characters.
 * - Included at the top of all pages that need database access.
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host   = '127.0.0.1';
$user   = 'root';
$pass   = '';
$dbname = 'ClothingStore';
$port   = 3306;

$conn = new mysqli($host, $user, $pass, $dbname, $port);

if ($conn->connect_error) {
    die("<h2 style='color:red'>DB Connection Failed: " . $conn->connect_error . "</h2>");
}

$conn->set_charset("utf8mb4");