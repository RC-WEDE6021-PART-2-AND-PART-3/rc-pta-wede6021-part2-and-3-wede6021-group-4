<?php
/**
 * admin/orders.php
 * Pastimes — Order Management
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Admin page for managing customer orders.
 * - Displays orders from tblOrder with buyer and product information.
 * - Allows updating order status: pending → confirmed → in-transit → delivered.
 * - Filter tabs show orders by status.
 * - Search functionality to find orders by customer or product.
 * - INNER JOIN with tblUser and tblClothes to show related data.
 */
session_start();
require_once '../DBConn.php';

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Handle Update Order Status
if (isset($_GET['update_status']) && isset($_GET['status'])) {
    $orderID = intval($_GET['update_status']);
    $newStatus = $_GET['status'];
    $stmt = $conn->prepare("UPDATE tblOrder SET orderStatus = ? WHERE orderID = ?");
    $stmt->bind_param("si", $newStatus, $orderID);
    $stmt->execute();
    $stmt->close();
    header('Location: orders.php?msg=updated');
    exit();
}

// Get filter from URL
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query to get all orders with buyer and product info
$sql = "SELECT o.*, u.fullName as buyerName, u.email as buyerEmail, 
               c.brand, c.category, c.clothesSize, c.price as productPrice
        FROM tblOrder o 
        LEFT JOIN tblUser u ON o.buyerID = u.userID
        LEFT JOIN tblClothes c ON o.clothesID = c.clothesID";

$where = [];
if ($status_filter !== 'all') {
    $where[] = "o.orderStatus = '" . mysqli_real_escape_string($conn, $status_filter) . "'";
}
if (!empty($search)) {
    $where[] = "(u.fullName LIKE '%" . mysqli_real_escape_string($conn, $search) . "%' 
                 OR u.email LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                 OR c.brand LIKE '%" . mysqli_real_escape_string($conn, $search) . "%')";
}

if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY o.orderDate DESC";
$result = $conn->query($sql);

// Get counts for tabs
$total_all = $conn->query("SELECT COUNT(*) as c FROM tblOrder")->fetch_assoc()['c'];
$total_pending = $conn->query("SELECT COUNT(*) as c FROM tblOrder WHERE orderStatus = 'pending'")->fetch_assoc()['c'];
$total_confirmed = $conn->query("SELECT COUNT(*) as c FROM tblOrder WHERE orderStatus = 'confirmed'")->fetch_assoc()['c'];
$total_transit = $conn->query("SELECT COUNT(*) as c FROM tblOrder WHERE orderStatus = 'in-transit'")->fetch_assoc()['c'];
$total_delivered = $conn->query("SELECT COUNT(*) as c FROM tblOrder WHERE orderStatus = 'delivered'")->fetch_assoc()['c'];

$message = '';
if (isset($_GET['msg'])) {
    $message = 'Order status updated successfully!';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Orders & Deliveries</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/orders.css">

<style>
/* Alert message */
.alert-success {
    background: #D1FAE5;
    color: #065F46;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 1rem;
    border-left: 3px solid #065F46;
}

/* Status badges */
.badge-pending {
    background: #FEF3C7;
    color: #92400E;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.badge-confirmed {
    background: #DBEAFE;
    color: #1E40AF;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.badge-transit {
    background: #E0E7FF;
    color: #3730A3;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.badge-delivered {
    background: #D1FAE5;
    color: #065F46;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

/* Action buttons spacing */
.act-cell {
    min-width: 140px !important;
    white-space: normal !important;
}

.act-cell select {
    padding: 5px 8px;
    border-radius: 6px;
    border: 1px solid #D4C4A8;
    font-size: 12px;
    background: #fff;
    cursor: pointer;
}

/* Table column widths */
.tbl th:nth-child(1) { width: 70px; }
.tbl th:nth-child(2) { width: 150px; }
.tbl th:nth-child(3) { width: 140px; }
.tbl th:nth-child(4) { width: 100px; }
.tbl th:nth-child(5) { width: 100px; }
.tbl th:nth-child(6) { width: 100px; }
.tbl th:nth-child(7) { width: 100px; }
.tbl th:nth-child(8) { width: 100px; }

/* Responsive */
@media (max-width: 1000px) {
    .tbl {
        display: block;
        overflow-x: auto;
    }
}
</style>
</head>
<body>

<div id="adminApp">
<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av"><?php echo strtoupper(substr($_SESSION['fullName'] ?? 'AD', 0, 2)); ?></div>
      <div>
        <div class="sb-admin-name"><?php echo htmlspecialchars($_SESSION['fullName'] ?? 'Admin User'); ?></div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>

    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item">Dashboard</a>

    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item">Seller Verification</a>

    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item">Manage Listings</a>

    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item on">Orders &amp; Deliveries</a>

    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item">User Management</a>

    <div class="sb-div"></div>
    <a href="../logout.php" class="sb-logout">Sign Out</a>
  </aside>

  <!-- MAIN COLUMN -->
  <div class="main-col">
    <div class="topbar">
      <div class="topbar-title">Orders & Deliveries</div>
      <div class="topbar-right">
        <form method="GET" action="" style="display:flex; gap:8px;">
          <div class="tb-search">
            <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>
            <input type="text" name="search" placeholder="Search by buyer or product..." value="<?php echo htmlspecialchars($search); ?>">
          </div>
          <button type="submit" class="btn btn-primary">Search</button>
          <?php if (!empty($search)): ?>
            <a href="orders.php" class="btn btn-outline">Clear</a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <div class="page-area">
      <div class="sec-head">
        <div>
          <div class="sec-title">Orders & Deliveries</div>
          <div class="sec-desc">Track and manage customer orders. Update order status as they move through the delivery process.</div>
        </div>
      </div>
      
      <?php if ($message): ?>
        <div class="alert-success">✓ <?php echo $message; ?></div>
      <?php endif; ?>
      
      <div class="tcard">
        <div class="ftabs">
          <a href="?status=all" class="ftab <?php echo $status_filter == 'all' ? 'on' : ''; ?>">All (<?php echo $total_all; ?>)</a>
          <a href="?status=pending" class="ftab <?php echo $status_filter == 'pending' ? 'on' : ''; ?>">Pending (<?php echo $total_pending; ?>)</a>
          <a href="?status=confirmed" class="ftab <?php echo $status_filter == 'confirmed' ? 'on' : ''; ?>">Confirmed (<?php echo $total_confirmed; ?>)</a>
          <a href="?status=in-transit" class="ftab <?php echo $status_filter == 'in-transit' ? 'on' : ''; ?>">In Transit (<?php echo $total_transit; ?>)</a>
          <a href="?status=delivered" class="ftab <?php echo $status_filter == 'delivered' ? 'on' : ''; ?>">Delivered (<?php echo $total_delivered; ?>)</a>
        </div>
        
        <table class="tbl">
          <thead>
            <tr>
              <th>Order #</th>
              <th>Customer</th>
              <th>Product</th>
              <th>Size</th>
              <th>Amount</th>
              <th>Order Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td style="font-weight:600;">#<?php echo $row['orderID']; ?></td>
                  <td>
                    <strong><?php echo htmlspecialchars($row['buyerName'] ?? 'Unknown'); ?></strong><br>
                    <small style="color:#8C8478;"><?php echo htmlspecialchars($row['buyerEmail'] ?? 'No email'); ?></small>
                  </div>
                  <td>
                    <strong><?php echo htmlspecialchars($row['brand'] ?? 'Unknown'); ?></strong><br>
                    <small style="color:#8C8478;"><?php echo htmlspecialchars($row['category'] ?? 'Product'); ?></small>
                  </div>
                  <td><?php echo htmlspecialchars($row['clothesSize'] ?? 'N/A'); ?></div>
                  <td style="font-weight:600; color:#B85C38;">R<?php echo number_format($row['total_amount'] ?? $row['productPrice'] ?? 0, 2); ?></td>
                  <td style="color:#8C8478; font-size:12px;"><?php echo date('M d, Y', strtotime($row['orderDate'])); ?></div>
                  <td>
                    <?php
                    $status = $row['orderStatus'];
                    if ($status == 'pending') {
                        echo '<span class="badge-pending">Pending</span>';
                    } elseif ($status == 'confirmed') {
                        echo '<span class="badge-confirmed">Confirmed</span>';
                    } elseif ($status == 'in-transit') {
                        echo '<span class="badge-transit">In Transit</span>';
                    } else {
                        echo '<span class="badge-delivered">Delivered</span>';
                    }
                    ?>
                  </div>
                  <td class="act-cell">
                    <select onchange="if(confirm('Update order status?')) window.location.href='?update_status=<?php echo $row['orderID']; ?>&status='+this.value">
                      <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>📋 Pending</option>
                      <option value="confirmed" <?php echo $status == 'confirmed' ? 'selected' : ''; ?>>✓ Confirm Order</option>
                      <option value="in-transit" <?php echo $status == 'in-transit' ? 'selected' : ''; ?>>🚚 Mark as Shipped</option>
                      <option value="delivered" <?php echo $status == 'delivered' ? 'selected' : ''; ?>>📦 Mark as Delivered</option>
                    </select>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" style="text-align:center; padding:2rem;">No orders found</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>

</body>
</html>
<?php $conn->close(); ?>