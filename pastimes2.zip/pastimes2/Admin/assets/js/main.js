// ============================================
// THREADBARE ADMIN PANEL - SHARED JAVASCRIPT
// ============================================

/* ── LOGIN ── */
function doLogin() {
  const e = document.getElementById('lemail').value.trim();
  const p = document.getElementById('lpass').value;
  if (e === 'admin@pastimes.co.za' && p === 'admin123') {
    // Redirect to dashboard on successful login
    window.location.href = 'dashboard.php';
  } else {
    toast('Incorrect credentials. Use the hint below.', 'warn');
  }
}

function doLogout() {
  // Redirect to login page
  window.location.href = 'index.php';
}

/* ── NAVIGATION (for pages that use dynamic nav) ── */
const titles = {
  dashboard: 'Dashboard',
  sellers: 'Seller Verification',
  listings: 'Manage Listings',
  orders: 'Orders & Deliveries',
  comms: 'Communications',
  users: 'User Management'
};

function nav(id, el) {
  document.querySelectorAll('.page-pane').forEach(p => p.classList.remove('on'));
  document.getElementById('pane-' + id).classList.add('on');
  document.getElementById('pageTitle').textContent = titles[id] || id;
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('on'));
  if (el) el.classList.add('on');
}

/* ── FILTER TABS ── */
function ftab(el) {
  el.closest('.ftabs').querySelectorAll('.ftab').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
}

/* ── SELLER ACTIONS ── */
function approveSeller(btn, name, rowId) {
  const row = btn.closest('tr');
  const badges = row.querySelectorAll('.badge');
  if (badges[0]) {
    badges[0].className = 'badge b-approved';
    badges[0].textContent = 'Approved';
  }
  if (badges[1]) {
    badges[1].className = 'badge b-approved';
  }
  row.querySelector('td:last-child').innerHTML = '<div class="act-cell"><button class="btn btn-view">View Profile</button><button class="btn btn-reject" onclick="toast(\'Seller suspended.\',\'warn\')">Suspend</button></div>';
  toast(name + ' approved — they can now list clothing for sale.', 'ok');
  const chip = document.getElementById('sellerChip');
  if (chip) {
    const n = parseInt(chip.textContent) - 1;
    if (n > 0) chip.textContent = n;
    else chip.style.display = 'none';
  }
}

function rejectSeller(btn, name, rowId) {
  const row = btn.closest('tr');
  const b = row.querySelector('.badge');
  if (b) {
    b.className = 'badge b-rejected';
    b.textContent = 'Rejected';
  }
  row.querySelector('td:last-child').innerHTML = '<div class="act-cell"><button class="btn btn-view">View</button><button class="btn btn-approve" onclick="approveSeller(this,\'' + name + '\',\'' + rowId + '\')">Re-approve</button></div>';
  toast(name + ' rejected. Seller has been notified.', 'warn');
}

/* ── LISTING ACTIONS ── */
function markSold(id, name) {
  const row = document.getElementById(id);
  if (!row) return;
  const b = row.querySelector('.badge');
  if (b) {
    b.className = 'badge b-sold';
    b.textContent = 'Sold';
  }
  row.querySelector('td:last-child').innerHTML = '<div class="act-cell"><button class="btn btn-view">View</button><span style="font-size:11.5px;color:var(--muted)">Removed from DB</span></div>';
  toast('"' + name + '" marked as sold. Removed from buyer shop. MySQL updated.', 'ok');
}

function removeListing(id, name) {
  const row = document.getElementById(id);
  if (!row) return;
  row.style.opacity = '0';
  row.style.transition = 'opacity .25s';
  setTimeout(() => row.remove(), 250);
  toast('"' + name + '" permanently deleted from the database. Seller notified.', 'warn');
}

/* ── ORDER ACTIONS ── */
function deliverOrder(id) {
  toast('Order ' + id + ' confirmed delivered. Payment released to seller. Buyer notified.', 'ok');
}

function openLiaise(id, buyer, seller) {
  document.getElementById('liaiseTitle').textContent = 'Liaise — Order ' + id;
  document.getElementById('liaiseBuyer').textContent = buyer;
  document.getElementById('liaiseSeller').textContent = seller;
  document.getElementById('m-liaise').classList.add('open');
}

function sendLiaise() {
  document.getElementById('m-liaise').classList.remove('open');
  toast('Mediation message sent to both buyer and seller.', 'ok');
}

function openDispute() {
  document.getElementById('m-dispute').classList.add('open');
}

function resolveDispute() {
  document.getElementById('m-dispute').classList.remove('open');
  toast('Dispute resolved. Full refund issued to buyer within 2 business days.', 'ok');
}

/* ── COMMS ── */
function openBroadcast() {
  document.getElementById('m-broadcast').classList.add('open');
}

function sendBroadcast() {
  document.getElementById('m-broadcast').classList.remove('open');
  toast('Broadcast sent to all 4,812 users successfully!', 'ok');
}

function openCompose() {
  document.getElementById('m-compose').classList.add('open');
}

function sendMsg() {
  const f = document.getElementById('chatField');
  const v = f.value.trim();
  if (!v) return;
  const body = document.getElementById('chatBody');
  const w = document.createElement('div');
  w.className = 'bubble-wrap';
  w.innerHTML = '<div class="bubble-meta right">Admin · Just now</div><div class="bubble from-admin">' + escapeHtml(v) + '</div>';
  body.appendChild(w);
  body.scrollTop = body.scrollHeight;
  f.value = '';
  toast('Message sent.', 'ok');
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

function selectChat(el, name, av, role) {
  document.querySelectorAll('.inbox-row').forEach(r => r.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('chatAv').textContent = av;
  document.getElementById('chatName').textContent = name;
  document.getElementById('chatSub').textContent = role + ' · Last seen recently';
}

/* ── MODAL ── */
function closeMod(id, e) {
  if (e.target === document.getElementById(id)) {
    document.getElementById(id).classList.remove('open');
  }
}

/* ── TOAST ── */
function toast(msg, type = 'ok') {
  const el = document.getElementById('toastEl');
  el.textContent = msg;
  el.className = 'toast ' + type + ' show';
  setTimeout(() => el.classList.remove('show'), 3500);
}