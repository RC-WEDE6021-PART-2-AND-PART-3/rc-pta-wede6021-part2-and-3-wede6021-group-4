<?php
session_start();
require_once '../DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Communications page - You can keep this mostly static or add messaging later
$adminName = $_SESSION['fullName'] ?? 'Admin User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Communications</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/comms.css">
</head>
<body>

<div id="adminApp">
<div class="shell">

  <!-- ── SIDEBAR (same structure, active='comms') ── -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av">AD</div>
      <div>
        <div class="sb-admin-name">Admin User</div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>

    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      Dashboard
    </a>

    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
      Seller Verification
      <span class="sb-chip">4</span>
    </a>

    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
      Manage Listings
    </a>

    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
      Orders &amp; Deliveries
      <span class="sb-chip">2</span>
    </a>

    <div class="sb-sec">Communications</div>
    <a href="comms.php" class="sb-item on">
      <svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      Communications
      <span class="sb-chip">5</span>
    </a>

    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
      User Management
    </a>

    <div class="sb-div"></div>
    <a href="index.php" class="sb-logout">
      <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      Sign Out
    </a>
  </aside>

  <!-- ── MAIN COLUMN ── -->
  <div class="main-col">

    <!-- TOP BAR -->
    <div class="topbar">
      <div class="topbar-title">Communications</div>
      <div class="topbar-right">
        <div class="tb-search">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>
          <input type="text" placeholder="Search users, orders, listings…">
        </div>
        <div class="tb-icon">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
          <div class="tb-dot"></div>
        </div>
      </div>
    </div>

    <!-- PAGE AREA -->
    <div class="page-area">
      <div class="sec-head" style="margin-bottom:1rem">
        <div>
          <div class="sec-title">Communications</div>
          <div class="sec-desc">Send direct messages to individual users or broadcast announcements to all buyers and sellers about new listings, promotions, or platform updates.</div>
        </div>
        <div class="sec-actions">
          <button class="btn btn-outline" onclick="openCompose()">+ New Message</button>
          <button class="btn btn-rust" onclick="openBroadcast()">📢 Broadcast to All</button>
        </div>
      </div>
      <div class="broadcast-strip">
        <div>
          <div style="font-size:12px;font-weight:600;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.07em;margin-bottom:3px">Last Broadcast</div>
          <p>"Winter collection is now live — check out 200+ new listings added this week!" — sent to <strong>4,812 users</strong> on 8 Apr 2025</p>
        </div>
        <button class="btn btn-outline" style="border-color:rgba(255,255,255,.25);color:#fff;flex-shrink:0" onclick="openBroadcast()">Send New</button>
      </div>
      <div class="comms-wrap">
        <div class="inbox-col">
          <div class="inbox-hd">
            <div class="inbox-hd-title">Inbox</div>
            <button class="btn btn-primary" style="padding:5px 12px;font-size:12px" onclick="openCompose()">+ New</button>
          </div>
          <div class="inbox-list">
            <div class="inbox-row on" onclick="selectChat(this,'Mzura K.','MK','Buyer')">
              <div class="inb-av">MK</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between"><div class="inb-name">Mzura K.</div><div class="inb-time">2h</div></div>
                <div class="inb-preview">Hi, I'm wondering about my order…</div>
                <div style="display:flex;gap:5px;margin-top:4px"><span class="badge b-buyer">Buyer</span><span class="inb-unread">2</span></div>
              </div>
            </div>
            <div class="inbox-row" onclick="selectChat(this,'@vintagevault_za','VV','Seller')">
              <div class="inb-av">VV</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between"><div class="inb-name">@vintagevault_za</div><div class="inb-time">3h</div></div>
                <div class="inb-preview">Can you confirm my listing is live?</div>
                <div style="display:flex;gap:5px;margin-top:4px"><span class="badge b-seller">Seller</span><span class="inb-unread">1</span></div>
              </div>
            </div>
            <div class="inbox-row" onclick="selectChat(this,'John P.','JP','Buyer')">
              <div class="inb-av" style="background:#F5E8E0;color:var(--rust)">JP</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between"><div class="inb-name">John P. <span style="font-size:10px;color:var(--rust)">⚠ Dispute</span></div><div class="inb-time">5h</div></div>
                <div class="inb-preview">The bag I received is NOT what was listed…</div>
                <div style="display:flex;gap:5px;margin-top:4px"><span class="badge b-buyer">Buyer</span><span class="inb-unread">2</span></div>
              </div>
            </div>
            <div class="inbox-row" onclick="selectChat(this,'Nomsa K.','NK','Seller')">
              <div class="inb-av">NK</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between"><div class="inb-name">Nomsa K.</div><div class="inb-time">Yesterday</div></div>
                <div class="inb-preview">How long does verification take?</div>
                <div style="margin-top:4px"><span class="badge b-seller">Seller</span></div>
              </div>
            </div>
            <div class="inbox-row" onclick="selectChat(this,'@closetclean','CC','Seller')">
              <div class="inb-av">CC</div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between"><div class="inb-name">@closetclean</div><div class="inb-time">Monday</div></div>
                <div class="inb-preview">Thanks for approving my account!</div>
                <div style="margin-top:4px"><span class="badge b-seller">Seller</span></div>
              </div>
            </div>
          </div>
        </div>
        <div class="chat-col">
          <div class="chat-hd">
            <div class="inb-av" id="chatAv">MK</div>
            <div>
              <div style="font-weight:600;font-size:14px;color:var(--charcoal)" id="chatName">Mzura K.</div>
              <div style="font-size:12px;color:var(--muted)" id="chatSub">Buyer · Last seen 2h ago</div>
            </div>
          </div>
          <div class="chat-body" id="chatBody">
            <div class="bubble-wrap">
              <div class="bubble-meta">Mzura K. · 10:02</div>
              <div class="bubble from-user">Hi, I'm wondering about the status of my order #TB-2055. It's been 3 days and I haven't received any tracking info yet.</div>
            </div>
            <div class="bubble-wrap">
              <div class="bubble-meta right">Admin · 10:15</div>
              <div class="bubble from-admin">Hi Mzura! Your order was picked up by Courier Guy yesterday. Tracking number: CG-29384756. Estimated delivery is 11 April. Let me know if you need anything!</div>
            </div>
            <div class="bubble-wrap">
              <div class="bubble-meta">Mzura K. · 10:18</div>
              <div class="bubble from-user">Thank you so much! Is there a way to track it online?</div>
            </div>
          </div>
          <div class="chat-input-row">
            <textarea class="chat-inp" rows="2" placeholder="Type your message to this user…" id="chatField"></textarea>
            <button class="btn btn-primary" onclick="sendMsg()" style="padding:10px 18px;align-self:flex-end">Send</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<!-- MODALS -->
<div class="overlay" id="m-broadcast" onclick="closeMod('m-broadcast',event)">
  <div class="modal">
    <div class="modal-close" onclick="document.getElementById('m-broadcast').classList.remove('open')">✕</div>
    <div class="modal-title">Broadcast Announcement</div>
    <div class="modal-desc">Send a platform-wide message. This will appear as a notification for every registered user in the selected group.</div>
    <div class="form-group">
      <label class="form-label">Send To</label>
      <select class="form-input"><option>All Users (4,812)</option><option>Buyers only (4,650)</option><option>Sellers only (160)</option><option>Approved sellers only</option></select>
    </div>
    <div class="form-group">
      <label class="form-label">Subject / Title</label>
      <input class="form-input" type="text" placeholder="e.g. New arrivals this week!">
    </div>
    <div class="form-group">
      <label class="form-label">Message</label>
      <textarea class="form-input" rows="5" placeholder="Write your announcement here…" style="resize:vertical;min-height:90px"></textarea>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="document.getElementById('m-broadcast').classList.remove('open')">Cancel</button>
      <button class="btn btn-rust" onclick="sendBroadcast()">📢 Send Broadcast</button>
    </div>
  </div>
</div>

<div class="overlay" id="m-compose" onclick="closeMod('m-compose',event)">
  <div class="modal">
    <div class="modal-close" onclick="document.getElementById('m-compose').classList.remove('open')">✕</div>
    <div class="modal-title">Compose Message</div>
    <div class="form-group"><label class="form-label">Recipient</label><input class="form-input" type="text" placeholder="Enter username or email…"></div>
    <div class="form-group"><label class="form-label">Subject</label><input class="form-input" type="text" placeholder="Message subject…"></div>
    <div class="form-group"><label class="form-label">Message</label><textarea class="form-input" rows="5" placeholder="Write your message…" style="resize:vertical;min-height:100px"></textarea></div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="document.getElementById('m-compose').classList.remove('open')">Cancel</button>
      <button class="btn btn-primary" onclick="toast('Message sent successfully.','ok');document.getElementById('m-compose').classList.remove('open')">Send Message</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toastEl"></div>

<script src="assets/js/main.js"></script>
</body>
</html>