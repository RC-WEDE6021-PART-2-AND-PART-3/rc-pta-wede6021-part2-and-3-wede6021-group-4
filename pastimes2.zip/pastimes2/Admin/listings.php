<?php
/**
 * admin/listings.php
 * Pastimes — Product Listings Management
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Admin page for managing all clothing listings.
 * - Displays products from tblClothes with seller information.
 * - Shows product details: brand, category, size, condition, price, status.
 * - Mark as Sold updates clothesStatus to 'sold'.
 * - Make Available updates clothesStatus to 'available'.
 * - Delete action permanently removes product from database.
 * - Search functionality to find products by brand, category, or seller.
 */
session_start();
require_once '../DBConn.php';

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Handle Delete Product
if (isset($_GET['delete'])) {
    $clothesID = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM tblClothes WHERE clothesID = ?");
    $stmt->bind_param("i", $clothesID);
    $stmt->execute();
    $stmt->close();
    header('Location: listings.php?msg=deleted');
    exit();
}

// Handle Mark as Sold
if (isset($_GET['sold'])) {
    $clothesID = intval($_GET['sold']);
    $stmt = $conn->prepare("UPDATE tblClothes SET clothesStatus = 'sold' WHERE clothesID = ?");
    $stmt->bind_param("i", $clothesID);
    $stmt->execute();
    $stmt->close();
    header('Location: listings.php?msg=sold');
    exit();
}

// Handle Make Available
if (isset($_GET['available'])) {
    $clothesID = intval($_GET['available']);
    $stmt = $conn->prepare("UPDATE tblClothes SET clothesStatus = 'available' WHERE clothesID = ?");
    $stmt->bind_param("i", $clothesID);
    $stmt->execute();
    $stmt->close();
    header('Location: listings.php?msg=available');
    exit();
}

// Get filter from URL
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query to get all products from tblClothes with seller info
$sql = "SELECT c.*, u.fullName as sellerName, u.username as sellerUsername 
        FROM tblClothes c 
        LEFT JOIN tblUser u ON c.sellerID = u.userID";

$where = [];
if ($status_filter !== 'all') {
    $where[] = "c.clothesStatus = '" . mysqli_real_escape_string($conn, $status_filter) . "'";
}
if (!empty($search)) {
    $where[] = "(c.brand LIKE '%" . mysqli_real_escape_string($conn, $search) . "%' 
                 OR c.category LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                 OR u.fullName LIKE '%" . mysqli_real_escape_string($conn, $search) . "%')";
}

if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY c.listedAt DESC";
$result = $conn->query($sql);

// Get counts for tabs
$total_all = $conn->query("SELECT COUNT(*) as c FROM tblClothes")->fetch_assoc()['c'];
$total_available = $conn->query("SELECT COUNT(*) as c FROM tblClothes WHERE clothesStatus = 'available'")->fetch_assoc()['c'];
$total_sold = $conn->query("SELECT COUNT(*) as c FROM tblClothes WHERE clothesStatus = 'sold'")->fetch_assoc()['c'];

$message = '';
if (isset($_GET['msg'])) {
    switch($_GET['msg']) {
        case 'deleted': $message = 'Product deleted successfully!'; break;
        case 'sold': $message = 'Product marked as sold!'; break;
        case 'available': $message = 'Product marked as available!'; break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Manage Listings</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/listings.css">

<style>
/* ============================================
   FIXED ACTION BUTTONS SPACING
   ============================================ */

/* Make action buttons display properly */
.act-cell {
    min-width: 180px !important;
    white-space: normal !important;
}

.act-cell .btn, 
.act-cell a.btn {
    display: inline-block !important;
    margin: 3px 4px !important;
    padding: 6px 12px !important;
    font-size: 11px !important;
    text-decoration: none !important;
    border-radius: 6px !important;
    font-weight: 500 !important;
    cursor: pointer !important;
    text-align: center !important;
    white-space: nowrap !important;
}

/* Specific button colors */
.btn-sold-action {
    background: #EDE8DF !important;
    color: #1C1C1A !important;
    border: 1px solid #D4C4A8 !important;
}

.btn-sold-action:hover {
    background: #1C1C1A !important;
    color: #fff !important;
}

.btn-available-action {
    background: #D1FAE5 !important;
    color: #065F46 !important;
    border: 1px solid #A7F3D0 !important;
}

.btn-available-action:hover {
    background: #065F46 !important;
    color: #fff !important;
}

.btn-delete-action {
    background: #FEE2E2 !important;
    color: #991B1B !important;
    border: 1px solid #FCA5A5 !important;
}

.btn-delete-action:hover {
    background: #991B1B !important;
    color: #fff !important;
}

/* Table column widths to ensure space */
.tbl th:nth-child(1) { width: 50px; }
.tbl th:nth-child(2) { width: 60px; }
.tbl th:nth-child(3) { width: 140px; }
.tbl th:nth-child(4) { width: 130px; }
.tbl th:nth-child(5) { width: 80px; }
.tbl th:nth-child(6) { width: 60px; }
.tbl th:nth-child(7) { width: 80px; }
.tbl th:nth-child(8) { width: 80px; }
.tbl th:nth-child(9) { width: 90px; }
.tbl th:nth-child(10) { width: 180px; }

/* Alert message */
.alert-success {
    background: #D1FAE5;
    color: #065F46;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 1rem;
    border-left: 3px solid #065F46;
}

/* Product image */
.product-image {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 8px;
    background: #EDE8DF;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Badge styles */
.badge-available {
    background: #D1FAE5;
    color: #065F46;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.badge-sold {
    background: #FEE2E2;
    color: #991B1B;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

/* Responsive */
@media (max-width: 1200px) {
    .act-cell {
        min-width: 200px !important;
    }
    .tbl th:nth-child(10) {
        width: 200px !important;
    }
}
</style>
</head>
<body>

<div id="adminApp">
<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av"><?php echo strtoupper(substr($_SESSION['fullName'] ?? 'AD', 0, 2)); ?></div>
      <div>
        <div class="sb-admin-name"><?php echo htmlspecialchars($_SESSION['fullName'] ?? 'Admin User'); ?></div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>

    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item">Dashboard</a>

    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item">Seller Verification</a>

    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item on">Manage Listings</a>

    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item">Orders &amp; Deliveries</a>

    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item">User Management</a>

    <div class="sb-div"></div>
    <a href="../logout.php" class="sb-logout">Sign Out</a>
  </aside>

  <!-- MAIN COLUMN -->
  <div class="main-col">
    <div class="topbar">
      <div class="topbar-title">Manage Listings</div>
      <div class="topbar-right">
        <form method="GET" action="" style="display:flex; gap:8px;">
          <div class="tb-search">
            <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>
            <input type="text" name="search" placeholder="Search by brand, category, seller..." value="<?php echo htmlspecialchars($search); ?>">
          </div>
          <button type="submit" class="btn btn-primary">Search</button>
          <?php if (!empty($search)): ?>
            <a href="listings.php" class="btn btn-outline">Clear</a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <div class="page-area">
      <div class="sec-head">
        <div>
          <div class="sec-title">Manage Listings</div>
          <div class="sec-desc">View, search, and manage all clothing listings on the platform.</div>
        </div>
      </div>
      
      <?php if ($message): ?>
        <div class="alert-success">✓ <?php echo $message; ?></div>
      <?php endif; ?>
      
      <div class="tcard">
        <div class="ftabs">
          <a href="?status=all" class="ftab <?php echo $status_filter == 'all' ? 'on' : ''; ?>">All (<?php echo $total_all; ?>)</a>
          <a href="?status=available" class="ftab <?php echo $status_filter == 'available' ? 'on' : ''; ?>">Available (<?php echo $total_available; ?>)</a>
          <a href="?status=sold" class="ftab <?php echo $status_filter == 'sold' ? 'on' : ''; ?>">Sold (<?php echo $total_sold; ?>)</a>
        </div>
        
        <table class="tbl">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Product</th>
              <th>Seller</th>
              <th>Price</th>
              <th>Size</th>
              <th>Condition</th>
              <th>Status</th>
              <th>Listed</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td style="text-align:center;">#<?php echo $row['clothesID']; ?></td>
                  <td style="text-align:center;">
                    <?php if (!empty($row['imagePath']) && file_exists("../" . $row['imagePath'])): ?>
                      <img src="../<?php echo $row['imagePath']; ?>" class="product-image" alt="<?php echo $row['brand']; ?>" style="width:45px; height:45px; object-fit:cover; border-radius:8px;">
                    <?php else: ?>
                      <div class="product-image" style="width:45px; height:45px; background:#EDE8DF; display:flex; align-items:center; justify-content:center; border-radius:8px;">👕</div>
                    <?php endif; ?>
                  </td>
                  <td>
                    <strong><?php echo htmlspecialchars($row['brand']); ?></strong><br>
                    <small style="color:#8C8478;"><?php echo htmlspecialchars($row['category']); ?></small>
                  </td>
                  <td>
                    <?php echo htmlspecialchars($row['sellerName'] ?? 'Unknown'); ?><br>
                    <small style="color:#8C8478;">@<?php echo htmlspecialchars($row['sellerUsername'] ?? 'unknown'); ?></small>
                  </td>
                  <td style="font-weight:600; color:#B85C38;">R<?php echo number_format($row['price'], 2); ?></td>
                  <td><?php echo htmlspecialchars($row['clothesSize']); ?></td>
                  <td><?php echo htmlspecialchars($row['conditionRating']); ?></td>
                  <td>
                    <?php if ($row['clothesStatus'] == 'available'): ?>
                      <span class="badge-available">Available</span>
                    <?php else: ?>
                      <span class="badge-sold">Sold</span>
                    <?php endif; ?>
                  </td>
                  <td style="color:#8C8478; font-size:12px;"><?php echo date('M d, Y', strtotime($row['listedAt'])); ?></td>
                  <td class="act-cell">
                    <?php if ($row['clothesStatus'] == 'available'): ?>
                      <a href="?sold=<?php echo $row['clothesID']; ?>" class="btn-sold-action" onclick="return confirm('Mark this item as sold?')" style="display:inline-block; margin:3px 4px; padding:6px 12px; background:#EDE8DF; color:#1C1C1A; text-decoration:none; border-radius:6px; font-size:11px;">✓ Mark Sold</a>
                    <?php else: ?>
                      <a href="?available=<?php echo $row['clothesID']; ?>" class="btn-available-action" onclick="return confirm('Mark this item as available again?')" style="display:inline-block; margin:3px 4px; padding:6px 12px; background:#D1FAE5; color:#065F46; text-decoration:none; border-radius:6px; font-size:11px;">↺ Make Available</a>
                    <?php endif; ?>
                    <a href="?delete=<?php echo $row['clothesID']; ?>" class="btn-delete-action" onclick="return confirm('Delete this listing permanently?')" style="display:inline-block; margin:3px 4px; padding:6px 12px; background:#FEE2E2; color:#991B1B; text-decoration:none; border-radius:6px; font-size:11px;">🗑 Delete</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="10" style="text-align:center; padding:2rem;">No listings found</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>

</body>
</html>
<?php $conn->close(); ?>