<?php
/**
 * admin/users.php
 * Pastimes — User Management
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Admin page for managing all registered users.
 * - Displays users from tblUser using fetch_assoc() associative array.
 * - ADD: Inserts a new user into tblUser using a prepared statement.
 * - EDIT: Updates an existing user's details using a prepared statement UPDATE query.
 * - DELETE: Removes a user from tblUser using a prepared statement DELETE query.
 * - All three operations use bind_param() to prevent SQL Injection.
 * - Admin accounts are protected from deletion.
 */
session_start();
require_once '../DBConn.php';

if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$message = '';
$message_type = 'success';

// ============================================================
// ADD NEW USER
// ============================================================
/**
 * TEACHING NOTE:
 * We read POST values, hash the password with bcrypt using password_hash(),
 * then INSERT into tblUser using a prepared statement.
 * bind_param("ssssss", ...) binds 6 string values to the ? placeholders.
 */
if (isset($_POST['add_user'])) {
    $fullName  = trim($_POST['fullName'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';
    $role      = $_POST['role'] ?? 'buyer';
    $status    = ($role === 'seller') ? 'pending' : 'verified';

    if (!empty($fullName) && !empty($email) && !empty($username) && !empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare(
            "INSERT INTO tblUser (fullName, email, username, userPassword, userRole, sellerStatus)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("ssssss", $fullName, $email, $username, $hashedPassword, $role, $status);
        if ($stmt->execute()) {
            $message = "User '$fullName' added successfully!";
        } else {
            $message = "Error adding user: " . $stmt->error;
            $message_type = 'error';
        }
        $stmt->close();
    } else {
        $message = "All fields are required to add a user.";
        $message_type = 'error';
    }
}

// ============================================================
// UPDATE / EDIT USER
// ============================================================
/**
 * TEACHING NOTE:
 * UPDATE query changes specific columns WHERE userID matches.
 * We use a prepared statement with bind_param to safely pass values.
 * "sssi" means: 3 strings + 1 integer.
 */
if (isset($_POST['edit_user'])) {
    $userID   = intval($_POST['userID']);
    $fullName = trim($_POST['fullName'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $role     = $_POST['role'] ?? 'buyer';

    $stmt = $conn->prepare(
        "UPDATE tblUser SET fullName = ?, email = ?, userRole = ? WHERE userID = ?"
    );
    $stmt->bind_param("sssi", $fullName, $email, $role, $userID);
    if ($stmt->execute()) {
        $message = "User updated successfully!";
    } else {
        $message = "Error updating user: " . $stmt->error;
        $message_type = 'error';
    }
    $stmt->close();
}

// ============================================================
// DELETE USER
// ============================================================
/**
 * TEACHING NOTE:
 * DELETE FROM removes the row WHERE userID matches.
 * intval() ensures the ID is always a safe integer.
 */
if (isset($_GET['delete'])) {
    $userID = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM tblUser WHERE userID = ?");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
    $message = "User deleted successfully!";
}

// ============================================================
// FETCH USER FOR EDITING
// ============================================================
$editUser = null;
if (isset($_GET['edit'])) {
    $editID = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM tblUser WHERE userID = ?");
    $stmt->bind_param("i", $editID);
    $stmt->execute();
    $editUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// ============================================================
// FETCH ALL USERS
// ============================================================
$role_filter = isset($_GET['role']) ? $_GET['role'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$sql = "SELECT userID, fullName, email, username, userRole, sellerStatus, createdAt FROM tblUser";
$where = [];
if ($role_filter !== 'all') {
    $where[] = "userRole = '" . mysqli_real_escape_string($conn, $role_filter) . "'";
}
if (!empty($search)) {
    $where[] = "(fullName LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                 OR email LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
                 OR username LIKE '%" . mysqli_real_escape_string($conn, $search) . "%')";
}
if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY createdAt DESC";
$result = $conn->query($sql);

// Tab counts
$total_all     = $conn->query("SELECT COUNT(*) as c FROM tblUser")->fetch_assoc()['c'];
$total_buyers  = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'buyer'")->fetch_assoc()['c'];
$total_sellers = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller'")->fetch_assoc()['c'];
$total_admins  = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'admin'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — User Management</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<style>
.form-card {
    background: #fff;
    border: 1px solid #E8E0D8;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}
.form-card h3 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 1rem;
    color: #1C1C1A;
}
.form-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    align-items: flex-end;
}
.form-row input, .form-row select {
    padding: 8px 12px;
    border: 1px solid #D4C4A8;
    border-radius: 8px;
    font-size: 13px;
    font-family: inherit;
    background: #fff;
    flex: 1;
    min-width: 140px;
}
.form-row input:focus, .form-row select:focus {
    outline: none;
    border-color: #8B1A1A;
}
.btn-add {
    background: #8B1A1A;
    color: #fff;
    border: none;
    padding: 9px 20px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
}
.btn-add:hover { background: #6b1414; }
.btn-edit-save {
    background: #1a6b1a;
    color: #fff;
    border: none;
    padding: 9px 20px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
}
.btn-cancel {
    background: #888;
    color: #fff;
    border: none;
    padding: 9px 20px;
    border-radius: 8px;
    font-size: 13px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}
.alert-success {
    background: #D1FAE5;
    color: #065F46;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 1rem;
    border-left: 3px solid #065F46;
}
.alert-error {
    background: #FEE2E2;
    color: #991B1B;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 1rem;
    border-left: 3px solid #991B1B;
}
.btn-delete {
    display: inline-block;
    padding: 5px 10px;
    background: #FEE2E2;
    color: #991B1B;
    border-radius: 6px;
    font-size: 11px;
    text-decoration: none;
    margin: 2px;
}
.btn-delete:hover { background: #991B1B; color: #fff; }
.btn-edit {
    display: inline-block;
    padding: 5px 10px;
    background: #EDE8DF;
    color: #1C1C1A;
    border-radius: 6px;
    font-size: 11px;
    text-decoration: none;
    margin: 2px;
}
.btn-edit:hover { background: #1C1C1A; color: #fff; }
</style>
</head>
<body>
<div id="adminApp">
<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av"><?php echo strtoupper(substr($_SESSION['fullName'] ?? 'AD', 0, 2)); ?></div>
      <div>
        <div class="sb-admin-name"><?php echo htmlspecialchars($_SESSION['fullName'] ?? 'Admin User'); ?></div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>
    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item">Dashboard</a>
    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item">Seller Verification</a>
    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item">Manage Listings</a>
    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item">Orders &amp; Deliveries</a>
    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item on">User Management</a>
    <div class="sb-div"></div>
    <a href="../logout.php" class="sb-logout">Sign Out</a>
  </aside>

  <!-- MAIN COLUMN -->
  <div class="main-col">
    <div class="topbar">
      <div class="topbar-title">User Management</div>
      <div class="topbar-right">
        <form method="GET" action="" style="display:flex; gap:8px;">
          <div class="tb-search">
            <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>
            <input type="text" name="search" placeholder="Search by name, email..." value="<?php echo htmlspecialchars($search); ?>">
          </div>
          <button type="submit" class="btn btn-primary">Search</button>
          <?php if (!empty($search)): ?>
            <a href="users.php" class="btn btn-outline">Clear</a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <div class="page-area">
      <div class="sec-head">
        <div>
          <div class="sec-title">User Management</div>
          <div class="sec-desc">Add, edit, and delete registered users — buyers, sellers, and admins.</div>
        </div>
      </div>

      <?php if ($message): ?>
        <div class="<?php echo $message_type === 'error' ? 'alert-error' : 'alert-success'; ?>">
          ✓ <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>

      <!--
        ============================================================
        ADD NEW USER FORM
        ============================================================
        TEACHING NOTE:
        This form POSTs to itself. When submitted, the PHP above
        reads $_POST['add_user'] and inserts the new user into tblUser
        using a prepared statement with password_hash() for the password.
      -->
      <?php if (!$editUser): ?>
      <div class="form-card">
        <h3>+ Add New User</h3>
        <form method="POST" action="">
          <div class="form-row">
            <input type="text" name="fullName" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password (8+ chars)" minlength="8" required>
            <select name="role">
              <option value="buyer">Buyer</option>
              <option value="seller">Seller</option>
              <option value="admin">Admin</option>
            </select>
            <button type="submit" name="add_user" class="btn-add">Add User</button>
          </div>
        </form>
      </div>
      <?php endif; ?>

      <!--
        ============================================================
        EDIT USER FORM
        ============================================================
        TEACHING NOTE:
        When the admin clicks Edit on a user, the page reloads with
        ?edit=ID in the URL. PHP fetches that user's data and pre-fills
        this form. On submit, the UPDATE query runs above.
      -->
      <?php if ($editUser): ?>
      <div class="form-card" style="border-color:#8B1A1A;">
        <h3>✏️ Editing User: <?php echo htmlspecialchars($editUser['fullName']); ?></h3>
        <form method="POST" action="">
          <input type="hidden" name="userID" value="<?php echo $editUser['userID']; ?>">
          <div class="form-row">
            <input type="text" name="fullName" value="<?php echo htmlspecialchars($editUser['fullName']); ?>" placeholder="Full Name" required>
            <input type="email" name="email" value="<?php echo htmlspecialchars($editUser['email']); ?>" placeholder="Email" required>
            <select name="role">
              <option value="buyer"  <?php echo $editUser['userRole'] === 'buyer'  ? 'selected' : ''; ?>>Buyer</option>
              <option value="seller" <?php echo $editUser['userRole'] === 'seller' ? 'selected' : ''; ?>>Seller</option>
              <option value="admin"  <?php echo $editUser['userRole'] === 'admin'  ? 'selected' : ''; ?>>Admin</option>
            </select>
            <button type="submit" name="edit_user" class="btn-edit-save">Save Changes</button>
            <a href="users.php" class="btn-cancel">Cancel</a>
          </div>
        </form>
      </div>
      <?php endif; ?>

      <!-- FILTER TABS -->
      <div class="tcard">
        <div class="ftabs">
          <a href="?role=all" class="ftab <?php echo $role_filter == 'all' ? 'on' : ''; ?>">All Users (<?php echo $total_all; ?>)</a>
          <a href="?role=buyer" class="ftab <?php echo $role_filter == 'buyer' ? 'on' : ''; ?>">Buyers (<?php echo $total_buyers; ?>)</a>
          <a href="?role=seller" class="ftab <?php echo $role_filter == 'seller' ? 'on' : ''; ?>">Sellers (<?php echo $total_sellers; ?>)</a>
          <a href="?role=admin" class="ftab <?php echo $role_filter == 'admin' ? 'on' : ''; ?>">Admins (<?php echo $total_admins; ?>)</a>
        </div>

        <!--
          TEACHING NOTE: fetch_assoc() in a while loop
          Each row from tblUser is read as an associative array.
          We access columns by name: $row['fullName'], $row['userRole'], etc.
        -->
        <table class="tbl">
          <thead>
            <tr>
              <th>ID</th>
              <th>Full Name</th>
              <th>Email</th>
              <th>Username</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td class="dim"><?php echo $row['userID']; ?></td>
                  <td><strong><?php echo htmlspecialchars($row['fullName']); ?></strong></td>
                  <td class="dim"><?php echo htmlspecialchars($row['email']); ?></td>
                  <td class="dim">@<?php echo htmlspecialchars($row['username']); ?></td>
                  <td>
                    <?php
                    $role = $row['userRole'];
                    if ($role == 'buyer') {
                        echo '<span style="background:#DBEAFE; color:#1E40AF; padding:4px 10px; border-radius:20px; font-size:11px;">Buyer</span>';
                    } elseif ($role == 'seller') {
                        echo '<span style="background:#E0E7FF; color:#3730A3; padding:4px 10px; border-radius:20px; font-size:11px;">Seller</span>';
                    } else {
                        echo '<span style="background:#EDE8DF; color:#1C1C1A; padding:4px 10px; border-radius:20px; font-size:11px;">Admin</span>';
                    }
                    ?>
                  </td>
                  <td>
                    <?php
                    $s = $row['sellerStatus'];
                    if ($s == 'verified') {
                        echo '<span style="background:#D1FAE5; color:#065F46; padding:4px 10px; border-radius:20px; font-size:11px;">Verified</span>';
                    } elseif ($s == 'pending') {
                        echo '<span style="background:#FEF3C7; color:#92400E; padding:4px 10px; border-radius:20px; font-size:11px;">Pending</span>';
                    } else {
                        echo '<span style="background:#FEE2E2; color:#991B1B; padding:4px 10px; border-radius:20px; font-size:11px;">' . ucfirst($s) . '</span>';
                    }
                    ?>
                  </td>
                  <td>
                    <?php if ($row['userRole'] !== 'admin'): ?>
                      <a href="?edit=<?php echo $row['userID']; ?>" class="btn-edit">✏️ Edit</a>
                      <a href="?delete=<?php echo $row['userID']; ?>" class="btn-delete"
                         onclick="return confirm('Permanently delete <?php echo addslashes($row['fullName']); ?>?')">🗑 Delete</a>
                    <?php else: ?>
                      <span style="font-size:11px; color:#8C8478;">Protected</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="7" style="text-align:center; padding:2rem;">No users found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
</body>
</html>
<?php $conn->close(); ?>