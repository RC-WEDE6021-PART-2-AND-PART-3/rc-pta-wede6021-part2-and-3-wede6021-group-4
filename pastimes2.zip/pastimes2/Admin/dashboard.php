<?php
/**
 * admin/dashboard.php
 * Pastimes — Admin Dashboard
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Accessible only to users with admin role.
 * - Displays key statistics from database (users, sellers, products, orders).
 * - Shows recent user registrations and recent orders.
 * - Quick action buttons for common admin tasks.
 * - Sidebar navigation to all admin sections.
 * - Requires admin authentication via session check.
 */
session_start();
require_once '../DBConn.php';

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Get dashboard statistics from database (fixed queries)
$total_users = $conn->query("SELECT COUNT(*) as count FROM tblUser")->fetch_assoc()['count'];
$total_buyers = $conn->query("SELECT COUNT(*) as count FROM tblUser WHERE userRole = 'buyer'")->fetch_assoc()['count'];
$total_sellers = $conn->query("SELECT COUNT(*) as count FROM tblUser WHERE userRole = 'seller'")->fetch_assoc()['count'];
$pending_sellers = $conn->query("SELECT COUNT(*) as count FROM tblUser WHERE userRole = 'seller' AND sellerStatus = 'pending'")->fetch_assoc()['count'];
$total_products = $conn->query("SELECT COUNT(*) as count FROM tblClothes WHERE clothesStatus = 'available'")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(*) as count FROM tblOrder")->fetch_assoc()['count'];
$pending_orders = $conn->query("SELECT COUNT(*) as count FROM tblOrder WHERE orderStatus = 'pending'")->fetch_assoc()['count'];

// Get recent users
$recent_users = $conn->query("SELECT userID, fullName, email, username, userRole, createdAt FROM tblUser ORDER BY createdAt DESC LIMIT 5");

// Get recent orders (removed total_amount column that doesn't exist)
$recent_orders = $conn->query("SELECT o.orderID, o.orderStatus, o.orderDate, u.fullName as buyerName 
                               FROM tblOrder o 
                               LEFT JOIN tblUser u ON o.buyerID = u.userID 
                               ORDER BY o.orderDate DESC LIMIT 5");

$adminName = $_SESSION['fullName'] ?? 'Admin User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

<div id="adminApp">
<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av"><?php echo strtoupper(substr($adminName, 0, 2)); ?></div>
      <div>
        <div class="sb-admin-name"><?php echo htmlspecialchars($adminName); ?></div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>

    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item on">
      <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      Dashboard
    </a>

    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
      Seller Verification
      <span class="sb-chip"><?php echo $pending_sellers; ?></span>
    </a>

    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
      Manage Listings
    </a>

    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
      Orders &amp; Deliveries
      <span class="sb-chip"><?php echo $pending_orders; ?></span>
    </a>

    <div class="sb-sec">Communications</div>
    <a href="comms.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      Communications
    </a>

    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item">
      <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
      User Management
    </a>

    <div class="sb-div"></div>
    <a href="../logout.php" class="sb-logout">
      <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      Sign Out
    </a>
  </aside>

  <!-- MAIN COLUMN -->
  <div class="main-col">

    <!-- TOP BAR -->
    <div class="topbar">
      <div class="topbar-title">Dashboard</div>
      <div class="topbar-right">
        <div class="tb-search">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><line x1="16.5" y1="16.5" x2="22" y2="22"/></svg>
          <input type="text" placeholder="Search users, orders, listings…">
        </div>
        <div class="tb-icon">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
          <div class="tb-dot"></div>
        </div>
      </div>
    </div>

    <!-- PAGE AREA -->
    <div class="page-area">
      <div class="sec-head">
        <div>
          <div class="sec-title">Dashboard</div>
          <div class="sec-desc">Welcome back, <?php echo htmlspecialchars($adminName); ?>. Here's what's happening on Pastimes today.</div>
        </div>
        <div class="sec-actions">
          <button class="btn btn-outline">Export Report</button>
        </div>
      </div>

      <!-- STATS ROW -->
      <div class="summary-strip">
        <div class="sum-item"><div class="sum-num"><?php echo $total_users; ?></div><div class="sum-lbl">Total Users</div></div>
        <div class="sum-item"><div class="sum-num rust"><?php echo $pending_sellers; ?></div><div class="sum-lbl">Pending Sellers</div></div>
        <div class="sum-item"><div class="sum-num olive"><?php echo $total_products; ?></div><div class="sum-lbl">Active Listings</div></div>
        <div class="sum-item"><div class="sum-num"><?php echo $total_orders; ?></div><div class="sum-lbl">Orders</div></div>
      </div>

      <!-- TWO COLUMN LAYOUT -->
      <div class="two-col">
        
        <!-- LEFT COLUMN: Recent Users -->
        <div class="tcard">
          <div class="tcard-head">
            <div class="tcard-title">Recent Users</div>
            <a href="users.php" class="btn btn-view" style="padding:4px 12px;">View all</a>
          </div>
          <table class="tbl">
            <thead>
              <tr><th>User</th><th>Role</th><th>Joined</th></tr>
            </thead>
            <tbody>
              <?php while ($user = $recent_users->fetch_assoc()): ?>
              <tr>
                <td>
                  <div class="urow">
                    <div class="uav"><?php echo strtoupper(substr($user['fullName'], 0, 2)); ?></div>
                    <div>
                      <div class="uname"><?php echo htmlspecialchars($user['fullName']); ?></div>
                      <div class="uemail"><?php echo htmlspecialchars($user['email']); ?></div>
                    </div>
                  </div>
                </td>
                <td>
                  <?php if ($user['userRole'] == 'buyer'): ?>
                    <span class="badge b-buyer">Buyer</span>
                  <?php elseif ($user['userRole'] == 'seller'): ?>
                    <span class="badge b-seller">Seller</span>
                  <?php else: ?>
                    <span class="badge b-admin">Admin</span>
                  <?php endif; ?>
                </td>
                <td class="dim"><?php echo date('M d, Y', strtotime($user['createdAt'])); ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>

        <!-- RIGHT COLUMN: Recent Orders -->
        <div class="tcard">
          <div class="tcard-head">
            <div class="tcard-title">Recent Orders</div>
            <a href="orders.php" class="btn btn-view" style="padding:4px 12px;">View all</a>
          </div>
          <table class="tbl">
            <thead>
              <tr><th>Order ID</th><th>Customer</th><th>Status</th><th>Date</th></tr>
            </thead>
            <tbody>
              <?php while ($order = $recent_orders->fetch_assoc()): ?>
              <tr>
                <td class="dim">#<?php echo $order['orderID']; ?></td>
                <td><div class="uname"><?php echo htmlspecialchars($order['buyerName'] ?? 'Unknown'); ?></div></td>
                <td>
                  <?php if ($order['orderStatus'] == 'pending'): ?>
                    <span class="badge b-pending">Pending</span>
                  <?php elseif ($order['orderStatus'] == 'confirmed'): ?>
                    <span class="badge b-confirmed">Confirmed</span>
                  <?php elseif ($order['orderStatus'] == 'in-transit'): ?>
                    <span class="badge b-transit">In Transit</span>
                  <?php else: ?>
                    <span class="badge b-delivered">Delivered</span>
                  <?php endif; ?>
                </td>
                <td class="dim"><?php echo date('M d', strtotime($order['orderDate'])); ?></td>
              </tr>
              <?php endwhile; ?>
              <?php if ($recent_orders->num_rows == 0): ?>
              <tr><td colspan="4" style="text-align:center; padding:2rem;">No orders yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- QUICK ACTIONS SECTION -->
      <div class="tcard" style="margin-top: 1rem;">
        <div class="tcard-head">
          <div class="tcard-title">Quick Actions</div>
        </div>
        <div style="display: flex; gap: 0.75rem; flex-wrap: wrap; padding: 0 1.4rem 1.4rem 1.4rem;">
          <a href="sellers.php?filter=pending" class="btn btn-primary">Verify Pending Sellers</a>
          <a href="listings.php" class="btn btn-outline">Manage Listings</a>
          <a href="orders.php?status=pending" class="btn btn-outline">Process Orders</a>
          <a href="users.php" class="btn btn-outline">Manage Users</a>
        </div>
      </div>

    </div>
  </div>
</div>
</div>

<!-- TOAST -->
<div class="toast" id="toastEl"></div>

<script src="assets/js/main.js"></script>
</body>
</html>
<?php $conn->close(); ?>