<?php
/**
 * admin/sellers.php
 * Pastimes — Seller Verification Management
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Admin page for approving or rejecting seller applications.
 * - Displays list of all users with seller role.
 * - Shows seller status: pending, verified, rejected.
 * - Approve updates sellerStatus to 'verified' in tblUser.
 * - Reject updates sellerStatus to 'rejected' in tblUser.
 * - Filter tabs show counts by status.
 * - Search functionality to find specific sellers.
 */
session_start();
require_once '../DBConn.php';

// Check if admin is logged in
if (!isset($_SESSION['userID']) || $_SESSION['userRole'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Handle Approve Seller
if (isset($_GET['approve'])) {
    $userID = intval($_GET['approve']);
    $stmt = $conn->prepare("UPDATE tblUser SET sellerStatus = 'verified' WHERE userID = ? AND userRole = 'seller'");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
    header('Location: sellers.php?msg=approved');
    exit();
}

// Handle Reject Seller
if (isset($_GET['reject'])) {
    $userID = intval($_GET['reject']);
    $stmt = $conn->prepare("UPDATE tblUser SET sellerStatus = 'rejected' WHERE userID = ? AND userRole = 'seller'");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
    header('Location: sellers.php?msg=rejected');
    exit();
}

// Handle Suspend Seller
if (isset($_GET['suspend'])) {
    $userID = intval($_GET['suspend']);
    $stmt = $conn->prepare("UPDATE tblUser SET sellerStatus = 'suspended' WHERE userID = ? AND userRole = 'seller'");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
    header('Location: sellers.php?msg=suspended');
    exit();
}

// Get filter from URL
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query to get sellers from database
$sql = "SELECT userID, fullName, email, username, sellerStatus, createdAt 
        FROM tblUser 
        WHERE userRole = 'seller'";

if ($filter !== 'all') {
    $sql .= " AND sellerStatus = '" . mysqli_real_escape_string($conn, $filter) . "'";
}

if (!empty($search)) {
    $sql .= " AND (fullName LIKE '%" . mysqli_real_escape_string($conn, $search) . "%' 
              OR email LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'
              OR username LIKE '%" . mysqli_real_escape_string($conn, $search) . "%')";
}

$sql .= " ORDER BY createdAt DESC";
$result = $conn->query($sql);

// Get counts for tabs
$total_sellers = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller'")->fetch_assoc()['c'];
$pending_count = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller' AND sellerStatus = 'pending'")->fetch_assoc()['c'];
$verified_count = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller' AND sellerStatus = 'verified'")->fetch_assoc()['c'];
$rejected_count = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller' AND sellerStatus = 'rejected'")->fetch_assoc()['c'];
$suspended_count = $conn->query("SELECT COUNT(*) as c FROM tblUser WHERE userRole = 'seller' AND sellerStatus = 'suspended'")->fetch_assoc()['c'];

$message = '';
if (isset($_GET['msg'])) {
    switch($_GET['msg']) {
        case 'approved': $message = 'Seller approved successfully!'; break;
        case 'rejected': $message = 'Seller rejected successfully!'; break;
        case 'suspended': $message = 'Seller suspended successfully!'; break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Seller Verification</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/sellers.css">
</head>
<body>

<div id="adminApp">
<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-logo">Pastimes</div>
      <div class="sb-sub">Admin Dashboard</div>
    </div>
    <div class="sb-admin">
      <div class="sb-av"><?php echo strtoupper(substr($_SESSION['fullName'] ?? 'AD', 0, 2)); ?></div>
      <div>
        <div class="sb-admin-name"><?php echo htmlspecialchars($_SESSION['fullName'] ?? 'Admin User'); ?></div>
        <div class="sb-admin-role">Super Administrator</div>
      </div>
    </div>

    <div class="sb-sec">Overview</div>
    <a href="dashboard.php" class="sb-item">Dashboard</a>

    <div class="sb-sec">Sellers</div>
    <a href="sellers.php" class="sb-item on">Seller Verification</a>

    <div class="sb-sec">Listings</div>
    <a href="listings.php" class="sb-item">Manage Listings</a>

    <div class="sb-sec">Orders</div>
    <a href="orders.php" class="sb-item">Orders &amp; Deliveries</a>

    <div class="sb-sec">Users</div>
    <a href="users.php" class="sb-item">User Management</a>

    <div class="sb-div"></div>
    <a href="../logout.php" class="sb-logout">Sign Out</a>
  </aside>

  <!-- MAIN COLUMN -->
  <div class="main-col">
    <div class="topbar">
      <div class="topbar-title">Seller Verification</div>
    </div>

    <div class="page-area">
      <div class="sec-head">
        <div>
          <div class="sec-title">Seller Verification</div>
          <div class="sec-desc">Review seller registrations and approve or reject them. Only approved sellers can list items for sale.</div>
        </div>
      </div>
      
      <?php if ($message): ?>
        <div class="alert alert-success">✓ <?php echo $message; ?></div>
      <?php endif; ?>
      
      <div class="tcard">
        <div class="ftabs">
          <a href="?filter=all" class="ftab <?php echo $filter == 'all' ? 'on' : ''; ?>">All (<?php echo $total_sellers; ?>)</a>
          <a href="?filter=pending" class="ftab <?php echo $filter == 'pending' ? 'on' : ''; ?>">Pending (<?php echo $pending_count; ?>)</a>
          <a href="?filter=verified" class="ftab <?php echo $filter == 'verified' ? 'on' : ''; ?>">Verified (<?php echo $verified_count; ?>)</a>
          <a href="?filter=rejected" class="ftab <?php echo $filter == 'rejected' ? 'on' : ''; ?>">Rejected (<?php echo $rejected_count; ?>)</a>
          <a href="?filter=suspended" class="ftab <?php echo $filter == 'suspended' ? 'on' : ''; ?>">Suspended (<?php echo $suspended_count; ?>)</a>
        </div>
        
        <table class="tbl">
          <thead>
            <tr>
              <th>Seller</th>
              <th>Email</th>
              <th>Username</th>
              <th>Registered</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td>
                    <div>
                      <strong><?php echo htmlspecialchars($row['fullName']); ?></strong><br>
                      <small>@<?php echo htmlspecialchars($row['username']); ?></small>
                    </div>
                   </div>
                  </td>
                  <td><?php echo htmlspecialchars($row['email']); ?></td>
                  <td><?php echo htmlspecialchars($row['username']); ?></td>
                  <td><?php echo date('M d, Y', strtotime($row['createdAt'])); ?></td>
                  <td>
                    <?php
                      $status = $row['sellerStatus'];
                      if ($status == 'pending') {
                        echo '<span class="badge b-pending">Pending</span>';
                      } elseif ($status == 'verified') {
                        echo '<span class="badge b-approved">Verified</span>';
                      } elseif ($status == 'rejected') {
                        echo '<span class="badge b-rejected">Rejected</span>';
                      } else {
                        echo '<span class="badge b-suspended">Suspended</span>';
                      }
                    ?>
                  </div>
                  <td>
                    <?php if ($status == 'pending'): ?>
                      <a href="?approve=<?php echo $row['userID']; ?>" class="btn btn-approve" onclick="return confirm('Approve this seller?')">Approve</a>
                      <a href="?reject=<?php echo $row['userID']; ?>" class="btn btn-reject" onclick="return confirm('Reject this seller?')">Reject</a>
                    <?php elseif ($status == 'verified'): ?>
                      <a href="?suspend=<?php echo $row['userID']; ?>" class="btn btn-reject" onclick="return confirm('Suspend this seller?')">Suspend</a>
                    <?php elseif ($status == 'suspended'): ?>
                      <a href="?approve=<?php echo $row['userID']; ?>" class="btn btn-approve" onclick="return confirm('Reinstate this seller?')">Reinstate</a>
                    <?php endif; ?>
                   </div>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="6" style="text-align:center; padding:2rem;">No sellers found</td>
              </tr>
            <?php endif; ?>
          </tbody>
         </>
      </div>
    </div>
  </div>
</div>
</div>

</body>
</html>
<?php $conn->close(); ?>