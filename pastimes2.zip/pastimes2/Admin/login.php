<?php
/**
 * admin/login.php
 * Pastimes — Admin Login Page
 * ST10452317 - Emihle Zifo | ST10345918 - Mzukisi Tekeni
 * WEDE6021POE
 *
 * TEACHING NOTES:
 * - Separate login page for administrator access.
 * - Queries tblUser for admin role verification.
 * - Uses password_verify() to authenticate admin credentials.
 * - On success, stores admin details in session.
 * - Redirects to admin dashboard after successful login.
 * - Displays error message for invalid credentials.
 */
session_start();
require_once '../DBConn.php'; // Connect to main database

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (!empty($email) && !empty($password)) {
        // Query the main tblUser table for admin
        $stmt = $conn->prepare("SELECT userID, fullName, email, username, userPassword, userRole FROM tblUser WHERE email = ? AND userRole = 'admin'");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            
            // Verify password (using password_verify since passwords are hashed with bcrypt)
            if (password_verify($password, $admin['userPassword'])) {
                $_SESSION['userID']   = $admin['userID'];
                $_SESSION['fullName'] = $admin['fullName'];
                $_SESSION['email']    = $admin['email'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['userRole'] = $admin['userRole'];
                
                header('Location: dashboard.php');
                exit();
            } else {
                $error = 'Invalid password. Please try again.';
            }
        } else {
            $error = 'No admin account found with that email address.';
        }
        $stmt->close();
    } else {
        $error = 'Please enter your email and password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pastimes — Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/login.css">
<style>
.password-hint {
    margin-top: 12px;
    padding: 10px;
    background: #F0E8DF;
    border-radius: 8px;
    font-size: 12px;
    color: #1C1C1A;
    text-align: center;
    border-left: 3px solid #8B1A1A;
}
.password-hint strong {
    color: #8B1A1A;
}
.hint-icon {
    display: inline-block;
    margin-right: 5px;
    font-size: 14px;
}
</style>
</head>
<body>

<div id="loginScreen">
  <div class="login-bg">Pastimes</div>
  <div class="login-card">
    <div class="login-brand">
      <div class="login-logo">Pastimes</div>
      <div class="login-sub">Administrator Portal</div>
    </div>
    
    <?php if ($error): ?>
      <div style="background:#FEE2E2; color:#991B1B; padding:10px; border-radius:8px; margin-bottom:1rem; font-size:13px; text-align:center;">
        <?php echo $error; ?>
      </div>
    <?php endif; ?>
    
    <form method="POST" action="">
      <div class="form-group">
        <label class="form-label">Admin Email</label>
        <!--
          TEACHING NOTE: type="text" used instead of type="email"
          so the admin can type the full email address without
          browser validation blocking the form submission.
        -->
        <input class="form-input" name="email" type="text"
               placeholder="admin@pastimes.co.za" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input class="form-input" name="password" type="password"
               placeholder="Enter admin password" required>
      </div>
      <button type="submit" class="btn-login">Sign In</button>
    </form>
    
    <!-- LOGIN HINT FOR DEMONSTRATION PURPOSES -->
    <div class="password-hint">
      <span class="hint-icon">🔐</span>
      <strong>Admin Login:</strong> Email: <strong>admin@pastimes.co.za</strong> | Password: <strong>Admin@1234</strong>
    </div>
    
    <div class="login-hint">Use admin credentials from your database</div>
  </div>
</div>

</body>
</html>
<?php $conn->close(); ?>